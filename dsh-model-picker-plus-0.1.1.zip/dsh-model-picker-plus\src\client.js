/**
 * dsh-model-picker-plus - browser half.
 *
 * 接管输入区模型选择器插槽 conversation.input.model（priority: -1 覆盖内置的 0）：
 *   1) 每个模型后面显示强项标签（data/models.json 的 tags）；
 *   2) 每个提供商的模型列表可折叠；
 *   3) 免费 / 限免模型单独一个置顶分组（始终展开，跨 provider 汇总）；
 *   4) 每个提供商内部按 rank 由强到弱排序，无 rank 的排在后面并保持原始顺序。
 *
 * 手写 ModuleLoader 包：无打包器、无第三方依赖，除 shell 已提供的 react 之外不 require 任何东西。
 * client.js 由 scripts/build-client.mjs 把 data/models.json 内联进模板占位符得到。
 */
window.__ModuleLoader__.load({
	id: "dsh-model-picker-plus",
	factory: (require) => {
		var module = { exports: {} };
		var exports = module.exports;
		Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });

		const React = require("react");
		// 弹层挂到 body 上才躲得开输入框容器的裁剪（内置选择器用的是同一套做法）。
		let ReactDOM = null;
		try {
			ReactDOM = require("react-dom");
		} catch (error) {
			ReactDOM = null;
		}
		const h = React.createElement;
		const Fragment = React.Fragment;

		/* ------------------------------------------------------------------ 常量 */

		const NS = "modelPickerPlus";
		const STORAGE_KEY = "dsh.modelPickerPlus.collapsed";
		const SEARCH_THRESHOLD = 12;
		const TRIGGER_TAG_LIMIT = 2;
		const ROW_TAG_LIMIT = 3;
		const FREE_WORDS = ["免费", "限免", "free", "limited"];
		
		/* ---------------------------------------------------------- 埋点 / 插槽抢占 */
		
		const DIAG_KEY = "dsh.modelPickerPlus.diag";
		const BOOT_KEY = "dsh.modelPickerPlus.boot";
		const APPLY_KEY = "dsh.modelPickerPlus.apply";
		const RETRY_KEY = "dsh.modelPickerPlus.retry";
		const SELECT_KEY = "dsh.modelPickerPlus.select";
		const DIAG_INTERVAL = 5000;
		const SLOT_NAME = "conversation.input.model";
		const FREE_GROUP_ID = "__free__";
		const FALLBACK_PRIORITY = -1000;
		const WATCHDOG_INTERVAL = 1500;
		const WATCHDOG_FAST_ROUNDS = 20;
		const WATCHDOG_FAST_INTERVAL = 600;
		const WATCHDOG_SLOW_INTERVAL = 4000;
		
		let MOUNT_COUNT = 0;
		let POPUP_OPEN_COUNT = 0;
		let REGISTERED_PRIORITY = null;
		// apply 级埋点的活载体：模块作用域可见，组件挂载时也会往里补 mounts。
		let APPLY_DIAG = null;

		// 构建期由 scripts/build-client.mjs 替换为 data/models.json 的 JSON。
		const DATA = __DSH_MPP_DATA__;

		const EMPTY_DATA = {
			version: 1,
			providerOrder: [],
			freeProviders: [],
			freeModels: [],
			freeNamePatterns: [],
			models: {},
		};

		const EMPTY_SNAPSHOT = {
			current: null,
			routable: null,
			groups: [],
			failures: [],
			status: "loading",
			pending: null,
			error: null,
		};

		const DICTIONARIES = {
			zh: {
				"menu.label": "模型选择",
				"trigger.empty": "选择模型",
				"trigger.readonly": "只读",
				"group.free": "免费 · 限免",
				"badge.free": "免费",
				"badge.limited": "限免",
				"state.loading": "正在加载模型…",
				"state.empty": "没有可用的模型",
				"state.error": "模型目录加载失败",
				"state.noMatch": "没有匹配的模型",
				"search.placeholder": "过滤模型名 / 提供商 / 标签…",
				"toggle.expand": "展开",
				"toggle.collapse": "折叠",
				"effort.title": "推理强度",
				"effort.providerDefault": "默认",
				"notice.locked": "模型已锁定",
				"notice.unavailable": "当前是子会话，模型不可切换",
				"error.sessionInUse": "该会话正被其它写入端占用，请稍后再试",
				"error.selectFailed": "切换模型失败",
				"unit.models": "个模型",
			},
			en: {
				"menu.label": "Model selection",
				"trigger.empty": "Select model",
				"trigger.readonly": "read-only",
				"group.free": "Free · Limited free",
				"badge.free": "free",
				"badge.limited": "limited free",
				"state.loading": "Loading models…",
				"state.empty": "No models available",
				"state.error": "Failed to load the model catalog",
				"state.noMatch": "No matching model",
				"search.placeholder": "Filter by model, provider or tag…",
				"toggle.expand": "Expand",
				"toggle.collapse": "Collapse",
				"effort.title": "Reasoning effort",
				"effort.providerDefault": "Default",
				"notice.locked": "Models are locked",
				"notice.unavailable": "Sub-session: model switching is disabled",
				"error.sessionInUse": "This session is held by another writer, try again later",
				"error.selectFailed": "Failed to switch model",
				"unit.models": "models",
			},
		};

		/* ---------------------------------------------------------------- 小工具 */

		function cx() {
			const parts = [];
			for (let i = 0; i < arguments.length; i += 1) {
				const value = arguments[i];
				if (typeof value === "string" && value !== "") parts.push(value);
			}
			return parts.join(" ");
		}

		function fallbackT(key) {
			const zh = DICTIONARIES.zh;
			if (zh !== null && typeof zh === "object" && typeof zh[key] === "string") return zh[key];
			return key;
		}

		function modelKey(providerId, modelId) {
			return String(providerId) + "/" + String(modelId);
		}

		/* ------------------------------------------------------------- 数据归一化 */

		function normalizeData(raw) {
			const source = raw !== null && typeof raw === "object" ? raw : EMPTY_DATA;
			return {
				version: typeof source.version === "number" ? source.version : 1,
				providerOrder: Array.isArray(source.providerOrder)
					? source.providerOrder.filter((id) => typeof id === "string" && id !== "")
					: [],
				freeProviders: Array.isArray(source.freeProviders)
					? source.freeProviders.filter((id) => typeof id === "string" && id !== "")
					: [],
				freeModels: Array.isArray(source.freeModels)
					? source.freeModels.filter(
							(entry) =>
								entry !== null &&
								typeof entry === "object" &&
								typeof entry.provider === "string" &&
								typeof entry.model === "string",
						)
					: [],
				freeNamePatterns: Array.isArray(source.freeNamePatterns)
					? source.freeNamePatterns.filter((pattern) => typeof pattern === "string" && pattern !== "")
					: [],
				models:
					source.models !== null && typeof source.models === "object" && !Array.isArray(source.models)
						? source.models
						: {},
			};
		}

		const CATALOG = normalizeData(DATA);

		function buildLowerIndex() {
			const index = Object.create(null);
			const keys = Object.keys(CATALOG.models);
			for (let i = 0; i < keys.length; i += 1) index[keys[i].toLowerCase()] = keys[i];
			return index;
		}
		const LOWER_INDEX = buildLowerIndex();

		function compilePatterns() {
			const compiled = [];
			for (let i = 0; i < CATALOG.freeNamePatterns.length; i += 1) {
				const pattern = CATALOG.freeNamePatterns[i];
				try {
					compiled.push(new RegExp(pattern, "i"));
				} catch (error) {
					// 数据损坏：单个非法正则不应该影响其余判定
				}
			}
			return compiled;
		}
		const NAME_PATTERNS = compilePatterns();

		function buildFreeIndex() {
			const exact = Object.create(null);
			const wildcard = Object.create(null);
			for (let i = 0; i < CATALOG.freeModels.length; i += 1) {
				const entry = CATALOG.freeModels[i];
				const kind = entry.kind === "limited" ? "limited" : "free";
				const note = typeof entry.note === "string" ? entry.note : "";
				const key = modelKey(entry.provider, entry.model).toLowerCase();
				if (exact[key] === undefined) exact[key] = { kind: kind, note: note };
				if (entry.provider === "*") {
					const bare = String(entry.model).toLowerCase();
					if (wildcard[bare] === undefined) wildcard[bare] = { kind: kind, note: note };
				}
			}
			return { exact: exact, wildcard: wildcard };
		}
		const FREE_INDEX = buildFreeIndex();

		function lookupModel(providerId, modelId) {
			const key = modelKey(providerId, modelId);
			if (Object.prototype.hasOwnProperty.call(CATALOG.models, key)) {
				const entry = CATALOG.models[key];
				if (entry !== null && typeof entry === "object" && !Array.isArray(entry)) return entry;
			}
			const lowered = LOWER_INDEX[key.toLowerCase()];
			if (lowered !== undefined) {
				const entry = CATALOG.models[lowered];
				if (entry !== null && typeof entry === "object" && !Array.isArray(entry)) return entry;
			}
			return undefined;
		}

		function tagsOf(providerId, model) {
			const entry = lookupModel(providerId, model.id);
			if (entry === undefined || !Array.isArray(entry.tags)) return [];
			const out = [];
			for (let i = 0; i < entry.tags.length; i += 1) {
				const tag = entry.tags[i];
				if (typeof tag === "string" && tag !== "") out.push(tag);
			}
			return out;
		}

		function rankOf(providerId, model) {
			const entry = lookupModel(providerId, model.id);
			if (entry === undefined) return undefined;
			const rank = entry.rank;
			return typeof rank === "number" && isFinite(rank) ? rank : undefined;
		}

		// 免费判定优先级（信息更具体者优先）：
		//   freeModels 命中 kind === "limited"（exact 先，再 wildcard）
		//   > models 条目 free === true
		//   > freeModels 的其余命中（kind === "free"）
		//   > freeProviders
		//   > freeNamePatterns
		// 「限免」比「免费」更具体，所以清单里的 limited 命中要盖过 free===true，
		// 否则 freeModels 里的限免条目永远显示不出来。
		function freeFor(providerId, model) {
			const key = modelKey(providerId, model.id).toLowerCase();
			const bare = String(model.id).toLowerCase();
			const listed =
				FREE_INDEX.exact[key] !== undefined ? FREE_INDEX.exact[key] : FREE_INDEX.wildcard[bare];
			if (listed !== undefined && listed.kind === "limited") return listed;
			const entry = lookupModel(providerId, model.id);
			if (entry !== undefined && entry.free === true) {
				return { kind: "free", note: typeof entry.note === "string" ? entry.note : "" };
			}
			if (listed !== undefined) return listed;
			if (CATALOG.freeProviders.indexOf(String(providerId)) !== -1) return { kind: "free", note: "" };
			const name = typeof model.name === "string" && model.name !== "" ? model.name : String(model.id);
			for (let i = 0; i < NAME_PATTERNS.length; i += 1) {
				if (NAME_PATTERNS[i].test(name)) return { kind: "free", note: "" };
			}
			return undefined;
		}

		/* ------------------------------------------------------------------ 排序 */

		function providerRank(providerId) {
			const index = CATALOG.providerOrder.indexOf(providerId);
			return index === -1 ? Number.MAX_SAFE_INTEGER : index;
		}

		// rank 降序；无 rank 的排在后面按原始顺序；rank 相同保持原始顺序（稳定）。
		function sortModels(providerId, models) {
			const decorated = [];
			for (let i = 0; i < models.length; i += 1) {
				decorated.push({ model: models[i], index: i, rank: rankOf(providerId, models[i]) });
			}
			decorated.sort((left, right) => {
				const leftKnown = left.rank !== undefined;
				const rightKnown = right.rank !== undefined;
				if (leftKnown && rightKnown) {
					if (left.rank !== right.rank) return right.rank - left.rank;
					return left.index - right.index;
				}
				if (leftKnown !== rightKnown) return leftKnown ? -1 : 1;
				return left.index - right.index;
			});
			const out = [];
			for (let i = 0; i < decorated.length; i += 1) out.push(decorated[i].model);
			return out;
		}

		function sortGroupViews(groupViews) {
			const decorated = [];
			for (let i = 0; i < groupViews.length; i += 1) {
				decorated.push({ view: groupViews[i], index: i, order: providerRank(groupViews[i].providerId) });
			}
			decorated.sort((left, right) => {
				if (left.order !== right.order) return left.order - right.order;
				return left.index - right.index;
			});
			const out = [];
			for (let i = 0; i < decorated.length; i += 1) out.push(decorated[i].view);
			return out;
		}

		// 免费分组排序：先按 providerOrder，再按 rank 降序，最后保持原始顺序（稳定）。
		function sortFreeRows(rows) {
			const decorated = [];
			for (let i = 0; i < rows.length; i += 1) {
				decorated.push({
					row: rows[i],
					index: i,
					order: providerRank(rows[i].providerId),
					rank: rankOf(rows[i].providerId, rows[i].model),
				});
			}
			decorated.sort((left, right) => {
				if (left.order !== right.order) return left.order - right.order;
				const leftKnown = left.rank !== undefined;
				const rightKnown = right.rank !== undefined;
				if (leftKnown && rightKnown) {
					if (left.rank !== right.rank) return right.rank - left.rank;
					return left.index - right.index;
				}
				if (leftKnown !== rightKnown) return leftKnown ? -1 : 1;
				return left.index - right.index;
			});
			const out = [];
			for (let i = 0; i < decorated.length; i += 1) out.push(decorated[i].row);
			return out;
		}

		/* ------------------------------------------------------------ 视图模型构造 */

		function matchesQuery(row, txt) {
			if (txt === "") return true;
			const name = typeof row.model.name === "string" ? row.model.name : "";
			if (name.toLowerCase().indexOf(txt) !== -1) return true;
			if (row.modelId.toLowerCase().indexOf(txt) !== -1) return true;
			if (row.providerId.toLowerCase().indexOf(txt) !== -1) return true;
			if (row.providerName.toLowerCase().indexOf(txt) !== -1) return true;
			for (let i = 0; i < row.tags.length; i += 1) {
				if (row.tags[i].toLowerCase().indexOf(txt) !== -1) return true;
			}
			if (row.freeHit !== undefined) {
				for (let i = 0; i < FREE_WORDS.length; i += 1) {
					if (FREE_WORDS[i].indexOf(txt) !== -1) return true;
				}
			}
			return false;
		}

		function buildView(groups, txt) {
			const list = Array.isArray(groups) ? groups : [];
			const groupViews = [];
			const freeAll = [];
			const byKey = Object.create(null);
			const seenFree = Object.create(null);
			for (let i = 0; i < list.length; i += 1) {
				const group = list[i];
				if (group === null || typeof group !== "object") continue;
				const providerId = typeof group.id === "string" ? group.id : String(group.id);
				const providerName =
					typeof group.name === "string" && group.name !== "" ? group.name : providerId;
				const provider = { id: providerId, name: providerName };
				const models = Array.isArray(group.models) ? group.models : [];
				const sorted = sortModels(providerId, models);
				const rows = [];
				for (let j = 0; j < sorted.length; j += 1) {
					const model = sorted[j];
					if (model === null || typeof model !== "object") continue;
					const row = {
						providerId: providerId,
						providerName: providerName,
						provider: provider,
						group: group,
						model: model,
						modelId: typeof model.id === "string" ? model.id : String(model.id),
						tags: tagsOf(providerId, model),
						freeHit: freeFor(providerId, model),
					};
					const key = modelKey(providerId, row.modelId);
					if (byKey[key] === undefined) byKey[key] = row;
					if (row.freeHit !== undefined && seenFree[key] === undefined) {
						seenFree[key] = true;
						freeAll.push(row);
					}
					if (matchesQuery(row, txt)) rows.push(row);
				}
				groupViews.push({
					providerId: providerId,
					providerName: providerName,
					provider: provider,
					rows: rows,
					modelCount: models.length,
				});
			}
			const freeMatched = [];
			for (let i = 0; i < freeAll.length; i += 1) {
				if (matchesQuery(freeAll[i], txt)) freeMatched.push(freeAll[i]);
			}
			const freeRows = sortFreeRows(freeMatched);
			return { groups: sortGroupViews(groupViews), freeRows: freeRows, byKey: byKey };
		}

		function effortChoicesFor(reasoning, t) {
			if (reasoning === null || typeof reasoning !== "object") return [];
			const out = [];
			if (typeof reasoning.defaultEffort !== "string") {
				out.push({ effort: undefined, label: t("effort.providerDefault") });
			}
			const efforts = Array.isArray(reasoning.efforts) ? reasoning.efforts : [];
			for (let i = 0; i < efforts.length; i += 1) {
				const effort = efforts[i];
				if (effort === null || typeof effort !== "object") continue;
				const id = typeof effort.id === "string" ? effort.id : String(effort.id);
				out.push({
					effort: id,
					label: typeof effort.name === "string" && effort.name !== "" ? effort.name : id,
				});
			}
			return out;
		}

		function effortKeyOf(effort) {
			return effort === undefined ? "__default" : String(effort);
		}

		/* ----------------------------------------------------------- localStorage */

		function readCollapsed() {
			try {
				const raw = window.localStorage.getItem(STORAGE_KEY);
				if (raw === null || raw === undefined) return [];
				const parsed = JSON.parse(raw);
				if (!Array.isArray(parsed)) return [];
				const out = [];
				for (let i = 0; i < parsed.length; i += 1) {
					if (typeof parsed[i] === "string" && parsed[i] !== "") out.push(parsed[i]);
				}
				return out;
			} catch (error) {
				return [];
			}
		}

		function hasStoredCollapsed() {
			try {
				return window.localStorage.getItem(STORAGE_KEY) !== null;
			} catch (error) {
				return true;
			}
		}

		function writeCollapsed(ids) {
			try {
				window.localStorage.setItem(STORAGE_KEY, JSON.stringify(ids));
			} catch (error) {
				// 隐私模式 / 配额满：折叠状态退化为内存态即可
			}
		}
		
		function writeDiag(patch) {
			try {
				const payload = {
					v: 1,
					mounts: MOUNT_COUNT,
					at: Date.now(),
					groups: 0,
					totalModels: 0,
					current: null,
					available: false,
					locked: false,
					priority: REGISTERED_PRIORITY,
					lowestOther: null,
					weRender: false,
					entries: [],
					popupOpens: POPUP_OPEN_COUNT,
					collapsedCount: readCollapsed().length,
				};
				if (patch !== null && patch !== undefined) {
					const keys = [
						"groups",
						"totalModels",
						"current",
						"available",
						"locked",
						"priority",
						"lowestOther",
						"weRender",
						"entries",
					];
					for (let i = 0; i < keys.length; i += 1) {
						const key = keys[i];
						if (patch[key] !== undefined) payload[key] = patch[key];
					}
				}
				window.localStorage.setItem(DIAG_KEY, JSON.stringify(payload));
			} catch (error) {
				// 隐私模式 / 配额满：埋点写不进去不影响插件本身
			}
		}
		
		// retry 级埋点：facade 重试失败时记录 directoryFor 抛出的真实错误，
		// 用于离线诊断「为什么绑定一直拿不到」。
		function writeRetryDiag(info) {
			try {
				window.localStorage.setItem(RETRY_KEY, JSON.stringify(Object.assign({ v: 1, at: Date.now() }, info)));
			} catch (error) {}
		}
		
		// select 级埋点：记录每次选模型的入参和结果（含失败原文），离线诊断切换失败用。
		function safeJson(value) {
			if (value === undefined) return "undefined";
			try {
				return JSON.stringify(value).slice(0, 200);
			} catch (error) {
				return String(value);
			}
		}
		function writeSelectDiag(info) {
			try {
				window.localStorage.setItem(SELECT_KEY, JSON.stringify(Object.assign({ v: 1, at: Date.now() }, info)));
			} catch (error) {}
		}
		
		// apply 级埋点：每轮看门狗 / 每次注册 / 每次组件挂载都会刷新它。
		function writeApplyDiag() {
			try {
				if (APPLY_DIAG === null || APPLY_DIAG === undefined) return;
				APPLY_DIAG.at = Date.now();
				window.localStorage.setItem(APPLY_KEY, JSON.stringify(APPLY_DIAG));
			} catch (error) {
				// 埋点失败静默
			}
		}

		/* ------------------------------------------------------------------ 样式 */

		const CSS_TAG_ID = "dsh-model-picker-plus/picker.css";

		const CSS_RULES = [
			'.dmpp-root{position:relative;display:inline-flex;align-items:center;font-family:var(--dsw-font-family,inherit)}',
			'.dmpp-trigger{display:inline-flex;align-items:center;gap:6px;max-width:min(56vw,560px);padding:3px 7px;border:1px solid transparent;border-radius:var(--dsw-radius-md,8px);background:transparent;color:var(--dsw-alias-label-secondary,rgba(255,255,255,.72));font:inherit;font-size:12px;line-height:1.5;cursor:pointer;transition:background-color .12s ease,color .12s ease,border-color .12s ease}',
			'.dmpp-trigger:hover{background:var(--dsw-alias-interactive-bg-hover,rgba(255,255,255,.06));color:var(--dsw-alias-label-primary,rgba(255,255,255,.92))}',
			'.dmpp-trigger:active{background:var(--dsw-alias-interactive-bg-active,rgba(255,255,255,.1))}',
			'.dmpp-trigger:focus-visible{outline:var(--dsw-focus-ring-width,2px) solid var(--dsw-focus-ring-color,#4d6bfe);outline-offset:2px}',
			'.dmpp-trigger:disabled{cursor:not-allowed;color:var(--dsw-alias-label-dimmed,rgba(255,255,255,.35))}',
			'.dmpp-trigger:disabled:hover{background:transparent}',
			'.dmpp-root.is-locked .dmpp-trigger{border-color:var(--dsw-alias-border-l2,rgba(255,255,255,.14))}',
			'.dmpp-trigger-name{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:500}',
			'.dmpp-trigger-tags{display:inline-flex;gap:4px;flex:none}',
			'.dmpp-trigger-tag{padding:0 4px;border-radius:var(--dsw-radius-sm,4px);background:var(--dsw-alias-interactive-bg-hover,rgba(255,255,255,.08));color:var(--dsw-alias-label-tertiary,rgba(255,255,255,.56));font-size:10px;line-height:16px;white-space:nowrap}',
			'.dmpp-trigger-lock{flex:none;padding:0 4px;border:1px solid var(--dsw-alias-border-l3,rgba(255,255,255,.18));border-radius:var(--dsw-radius-sm,4px);color:var(--dsw-alias-label-caption,rgba(255,255,255,.5));font-size:10px;line-height:15px}',
			'.dmpp-caret{flex:none;font-size:9px;line-height:1;color:var(--dsw-alias-label-tertiary,rgba(255,255,255,.5))}',
			'.dmpp-popup{position:fixed;left:0;top:0;z-index:1100;display:flex;flex-direction:column;gap:2px;box-sizing:border-box;width:min(92vw,580px);max-height:min(560px,100vh - 24px);overflow-y:auto;overflow-x:hidden;padding:6px;border:1px solid var(--dsw-alias-border-l2,rgba(255,255,255,.12));border-radius:var(--dsw-radius-lg,12px);background:var(--dsw-alias-bg-layer-1,var(--dsw-alias-bg-layer-2,#1f2125));box-shadow:var(--dsw-elevation-panel,var(--dsw-shadow-lv3,0 12px 32px rgba(0,0,0,.36)));color:var(--dsw-alias-label-primary,rgba(255,255,255,.92));font-family:var(--dsw-font-family,inherit);font-size:12px}',
			'.dmpp-popup::-webkit-scrollbar{width:var(--dsh-scrollbar-width,8px)}',
			'.dmpp-popup::-webkit-scrollbar-thumb{border-radius:var(--dsw-radius-sm,4px);background:var(--dsh-scrollbar-thumb,rgba(255,255,255,.18))}',
			'.dmpp-popup::-webkit-scrollbar-track{background:transparent}',
			'.dmpp-notice{padding:6px 8px;border-radius:var(--dsw-radius-sm,4px);color:var(--dsw-alias-label-tertiary,rgba(255,255,255,.6));font-size:11px;line-height:1.5}',
			'.dmpp-notice.is-error{color:var(--dsw-alias-label-error,#e5646a);background:rgba(229,100,106,.1)}',
			'.dmpp-search{width:100%;box-sizing:border-box;margin:2px 0 4px;padding:5px 8px;border:1px solid var(--dsw-alias-border-l2,rgba(255,255,255,.14));border-radius:var(--dsw-radius-sm,6px);background:var(--dsw-alias-bg-layer-2,rgba(255,255,255,.04));color:var(--dsw-alias-label-primary,rgba(255,255,255,.92));font:inherit;font-size:12px}',
			'.dmpp-search::placeholder{color:var(--dsw-alias-label-dimmed,rgba(255,255,255,.35))}',
			'.dmpp-search:focus-visible{outline:var(--dsw-focus-ring-width,2px) solid var(--dsw-focus-ring-color,#4d6bfe);outline-offset:1px}',
			'.dmpp-section{display:flex;flex-direction:column;gap:1px}',
			'.dmpp-free-header{display:flex;align-items:center;gap:6px;width:100%;box-sizing:border-box;padding:4px 6px;margin-bottom:1px;border:0;border-radius:var(--dsw-radius-sm,4px);background:var(--dsw-alias-menu-group-header-fill,var(--dsw-alias-bg-layer-2,rgba(255,255,255,.05)));color:var(--dsw-alias-state-success-primary,#4bbf7a);font:inherit;font-size:11px;font-weight:600;letter-spacing:.02em;text-align:left;cursor:pointer}',
			'.dmpp-free-header:hover{background:var(--dsw-alias-interactive-bg-hover,rgba(255,255,255,.09))}',
			'.dmpp-free-header:focus-visible{outline:var(--dsw-focus-ring-width,2px) solid var(--dsw-focus-ring-color,#4d6bfe);outline-offset:-1px}',
			'.dmpp-free-header:disabled{cursor:not-allowed}',
			'.dmpp-free-count{margin-left:auto;padding:0 5px;border-radius:999px;background:rgba(75,191,122,.16);color:var(--dsw-alias-state-success-primary,#4bbf7a);font-size:10px;line-height:15px}',
			'.dmpp-group-header{display:flex;align-items:center;gap:6px;width:100%;padding:4px 6px;border:0;border-radius:var(--dsw-radius-sm,4px);background:transparent;color:var(--dsw-alias-label-tertiary,rgba(255,255,255,.62));font:inherit;font-size:11px;font-weight:600;text-align:left;cursor:pointer}',
			'.dmpp-group-header:hover{background:var(--dsw-alias-interactive-bg-hover,rgba(255,255,255,.06));color:var(--dsw-alias-label-secondary,rgba(255,255,255,.8))}',
			'.dmpp-group-header:focus-visible{outline:var(--dsw-focus-ring-width,2px) solid var(--dsw-focus-ring-color,#4d6bfe);outline-offset:-1px}',
			'.dmpp-group-name{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
			'.dmpp-group-count{margin-left:auto;color:var(--dsw-alias-label-dimmed,rgba(255,255,255,.4));font-size:10px;font-weight:400}',
			'.dmpp-arrow{flex:none;display:inline-block;width:9px;color:var(--dsw-alias-label-dimmed,rgba(255,255,255,.4));transition:transform .12s ease}',
			'.dmpp-arrow.is-open{transform:rotate(90deg)}',
			'.dmpp-section-body{display:flex;flex-direction:column;gap:1px;padding-left:9px}',
			'.dmpp-option{display:flex;align-items:center;gap:8px;width:100%;padding:4px 6px;border:0;border-radius:var(--dsw-radius-sm,4px);background:transparent;color:inherit;font:inherit;font-size:12px;text-align:left;cursor:pointer}',
			'.dmpp-option:hover,.dmpp-option.is-active{background:var(--dsw-alias-interactive-bg-hover,rgba(255,255,255,.07))}',
			'.dmpp-option.is-active{outline:var(--dsw-focus-ring-width,2px) solid var(--dsw-focus-ring-color,#4d6bfe);outline-offset:-2px}',
			'.dmpp-option.is-selected{color:var(--dsw-alias-label-primary,rgba(255,255,255,.96));font-weight:500}',
			'.dmpp-option:disabled{cursor:default;opacity:.6}',
			'.dmpp-option-main{display:flex;align-items:center;gap:6px;min-width:0;flex:1}',
			'.dmpp-option-name{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
			'.dmpp-tags{display:inline-flex;gap:3px;flex:none}',
			'.dmpp-tag{padding:0 4px;border-radius:var(--dsw-radius-sm,4px);background:var(--dsw-alias-interactive-bg-hover,rgba(255,255,255,.07));color:var(--dsw-alias-label-caption,rgba(255,255,255,.48));font-size:10px;line-height:15px;font-weight:400;white-space:nowrap}',
			'.dmpp-option-side{display:inline-flex;align-items:center;gap:4px;flex:none}',
			'.dmpp-badge{padding:0 4px;border-radius:var(--dsw-radius-sm,4px);font-size:10px;line-height:15px;white-space:nowrap}',
			'.dmpp-badge-free{border:1px solid var(--dsw-alias-state-success-primary,rgba(75,191,122,.6));color:var(--dsw-alias-state-success-primary,#4bbf7a)}',
			'.dmpp-badge-limited{border:1px solid var(--dsw-alias-state-warn-primary,rgba(214,158,46,.6));color:var(--dsw-alias-state-warn-primary,#d69e2e)}',
			'.dmpp-check{width:14px;color:var(--dsw-alias-state-success-primary,#4bbf7a);font-size:11px;text-align:center}',
			'.dmpp-spinner{display:inline-block;width:8px;height:8px;border:1px solid var(--dsw-alias-label-dimmed,rgba(255,255,255,.35));border-top-color:var(--dsw-alias-label-secondary,rgba(255,255,255,.8));border-radius:50%;animation:dmpp-spin .7s linear infinite}',
			'@keyframes dmpp-spin{to{transform:rotate(360deg)}}',
			'.dmpp-efforts{display:flex;flex-wrap:wrap;align-items:center;gap:4px;margin:1px 0 3px 14px;padding:4px 6px;border-left:2px solid var(--dsw-alias-border-l2,rgba(255,255,255,.12));border-radius:0 var(--dsw-radius-sm,4px) var(--dsw-radius-sm,4px) 0}',
			'.dmpp-efforts-title{color:var(--dsw-alias-label-dimmed,rgba(255,255,255,.42));font-size:10px;letter-spacing:.02em}',
			'.dmpp-effort{padding:1px 6px;border:1px solid var(--dsw-alias-border-l2,rgba(255,255,255,.14));border-radius:999px;background:transparent;color:var(--dsw-alias-label-tertiary,rgba(255,255,255,.6));font:inherit;font-size:10px;line-height:15px;cursor:pointer}',
			'.dmpp-effort:hover{background:var(--dsw-alias-interactive-bg-hover,rgba(255,255,255,.08));color:var(--dsw-alias-label-primary,rgba(255,255,255,.9))}',
			'.dmpp-effort.is-selected{border-color:var(--dsw-focus-ring-color,#4d6bfe);color:var(--dsw-alias-label-primary,rgba(255,255,255,.96))}',
			'.dmpp-effort:focus-visible{outline:var(--dsw-focus-ring-width,2px) solid var(--dsw-focus-ring-color,#4d6bfe);outline-offset:1px}',
			'.dmpp-effort:disabled{cursor:default;opacity:.55}',
		];

		const CSS = CSS_RULES.join("\n");

		function ensureStyle() {
			if (typeof document === "undefined") return;
			if (document.querySelector('style[data-plugin-css="' + CSS_TAG_ID + '"]') !== null) return;
			const tag = document.createElement("style");
			tag.dataset.plugin = "dsh-model-picker-plus";
			tag.dataset.pluginCss = CSS_TAG_ID;
			tag.textContent = CSS;
			if (document.head !== null && document.head !== undefined) document.head.appendChild(tag);
		}

		/* -------------------------------------------------------------- 组件 props */

		function createEmptyStore() {
			return {
				subscribe: () => () => {},
				getSnapshot: () => EMPTY_SNAPSHOT,
			};
		}

		function describeError(error) {
			if (error === null || error === undefined) return fallbackT("error.selectFailed");
			const code = typeof error === "object" && typeof error.code === "string" ? error.code : null;
			if (code === "session/writer-held") return fallbackT("error.sessionInUse");
			const message =
				typeof error === "string"
					? error
					: typeof error.message === "string"
						? error.message
						: "";
			return message === "" ? fallbackT("error.selectFailed") : message;
		}

		let INSTANCE_SEQ = 0;

		/* ------------------------------------------------------------------ 组件 */

		const MENU_MARGIN = 12;
		// 量到自身尺寸之前先藏起来摆在原点，这样 offsetWidth/offsetHeight 是真实值（内置选择器同款）。
		const MEASURE_STYLE = { visibility: "hidden", left: 0, top: 0 };

		/* 弹层摆放：挂到 body 之后按视口坐标摆，任何一边都不会越出窗口。
	   内置选择器用「量自身尺寸 → 右边缘对齐触发器右侧 → 夹进视口」这套算法，这里保持一致。 */
		function computeMenuPos(anchor, size, viewport, margin) {
			const gap = typeof margin === "number" && margin > 0 ? margin : MENU_MARGIN;
			const anchorLeft =
				anchor !== null && anchor !== undefined && typeof anchor.left === "number" ? anchor.left : gap;
			const anchorRight =
				anchor !== null && anchor !== undefined && typeof anchor.right === "number" ? anchor.right : anchorLeft;
			const anchorTop =
				anchor !== null && anchor !== undefined && typeof anchor.top === "number" ? anchor.top : gap;
			const width =
				size !== null && size !== undefined && typeof size.width === "number" && size.width > 0 ? size.width : 0;
			const height =
				size !== null && size !== undefined && typeof size.height === "number" && size.height > 0 ? size.height : 0;
			const viewWidth =
				viewport !== null && viewport !== undefined && typeof viewport.width === "number" && viewport.width > 0
					? viewport.width
					: 0;
			const viewHeight =
				viewport !== null && viewport !== undefined && typeof viewport.height === "number" && viewport.height > 0
					? viewport.height
					: 0;
			let left = width > 0 ? anchorRight - width : anchorLeft;
			let top = anchorTop - 8 - height;
			if (viewWidth > 0) left = Math.min(Math.max(left, gap), Math.max(gap, viewWidth - width - gap));
			if (viewHeight > 0) top = Math.min(Math.max(top, gap), Math.max(gap, viewHeight - height - gap));
			return { left: left, top: top };
		}
	function ModelSelectPlus(props) {
			const locked = props.locked === true;
			const available = props.available !== false;
			const interactive = available && !locked;
			const directory = props.directory;
			const select = props.select;
			const t = typeof props.t === "function" ? props.t : fallbackT;
			const renderSlot = props.renderSlot;

			const subscribe = React.useCallback(
				(onStoreChange) => {
					if (directory === null || directory === undefined) return () => {};
					if (typeof directory.subscribe !== "function") return () => {};
					return directory.subscribe(onStoreChange);
				},
				[directory],
			);
			const getSnapshot = React.useCallback(() => {
				if (directory === null || directory === undefined) return EMPTY_SNAPSHOT;
				if (typeof directory.getSnapshot !== "function") return EMPTY_SNAPSHOT;
				const snapshot = directory.getSnapshot();
				return snapshot === null || snapshot === undefined ? EMPTY_SNAPSHOT : snapshot;
			}, [directory]);
			const state = React.useSyncExternalStore(subscribe, getSnapshot);

			const idRef = React.useRef(null);
			if (idRef.current === null) {
				INSTANCE_SEQ += 1;
				idRef.current = "dmpp-" + INSTANCE_SEQ;
			}
			const menuId = idRef.current + "-menu";

			const rootRef = React.useRef(null);
			const triggerRef = React.useRef(null);
			const searchRef = React.useRef(null);
			const itemRefs = React.useRef([]);

			const [open, setOpen] = React.useState(false);
			const [query, setQuery] = React.useState("");
			const [activeId, setActiveId] = React.useState(null);
			const [collapsed, setCollapsed] = React.useState(readCollapsed);
			const [pendingId, setPendingId] = React.useState(null);
			const [errorText, setErrorText] = React.useState(null);
			const [menuPos, setMenuPos] = React.useState(null);
			const popupRef = React.useRef(null);
			const seededRef = React.useRef(false);

			const current = state.current !== null && typeof state.current === "object" ? state.current : null;
			const currentProviderId = current !== null ? String(current.provider) : null;
			const currentModelId = current !== null ? String(current.model) : null;
			const txt = query.trim().toLowerCase();

			const groups = Array.isArray(state.groups) ? state.groups : [];

			const view = React.useMemo(() => buildView(groups, txt), [groups, txt]);

			const totalModels = React.useMemo(() => {
				let total = 0;
				for (let i = 0; i < view.groups.length; i += 1) total += view.groups[i].modelCount;
				return total;
			}, [view]);

			// 运行期埋点：挂载即写一次，之后每 5s 刷新一次槽位与渲染状态。
			React.useEffect(() => {
				MOUNT_COUNT += 1;
				let timer = null;
				const flush = () => {
					try {
						const diagGroups = Array.isArray(state.groups) ? state.groups.length : 0;
						let diagTotal = 0;
						const diagView = view;
						if (diagView !== null && diagView !== undefined && Array.isArray(diagView.groups)) {
							for (let i = 0; i < diagView.groups.length; i += 1) {
								diagTotal += Number(diagView.groups[i].modelCount) || 0;
							}
						}
						const diagOptions = LAST_SLOT_OPTIONS;
						const lowest = lowestOtherPriority(LAST_SLOT_SCOPE);
						const mine = diagOptions === null ? null : Number(diagOptions.priority);
						writeDiag({
							groups: diagGroups,
							totalModels: diagTotal,
							current: currentProviderId !== null && currentModelId !== null ? currentProviderId + "/" + currentModelId : null,
							available: available,
							locked: locked,
							priority: mine,
							lowestOther: lowest === null ? null : lowest.priority,
							weRender: mine !== null && (lowest === null || lowest.priority > mine),
							entries: snapshotEntries(LAST_SLOT_SCOPE),
						});
						if (APPLY_DIAG !== null) {
							APPLY_DIAG.mounts = MOUNT_COUNT;
							writeApplyDiag();
						}
					} catch (error) {
						// 埋点失败静默
					}
				};
				flush();
				if (typeof setInterval === "function") timer = setInterval(flush, DIAG_INTERVAL);
				return () => {
					if (timer !== null && typeof clearInterval === "function") clearInterval(timer);
				};
			}, [state, view, currentProviderId, currentModelId, available, locked]);

			const currentRow =
				current !== null ? view.byKey[modelKey(currentProviderId, currentModelId)] : undefined;

			const effortChoices = React.useMemo(
				() => (currentRow === undefined ? [] : effortChoicesFor(currentRow.model.reasoning, t)),
				[currentRow, t],
			);

			const effectiveEffort =
				current !== null && typeof current.reasoningEffort === "string"
					? current.reasoningEffort
					: currentRow !== undefined && currentRow.model.reasoning !== null && typeof currentRow.model.reasoning === "object"
						? currentRow.model.reasoning.defaultEffort
						: undefined;

			const nav = React.useMemo(() => {
				const items = [];
			const collapsedSet = Object.create(null);
			for (let i = 0; i < collapsed.length; i += 1) collapsedSet[collapsed[i]] = true;
			const freeCollapsed = collapsedSet[FREE_GROUP_ID] === true;
			if (!freeCollapsed) {
					for (let i = 0; i < view.freeRows.length; i += 1) {
						const row = view.freeRows[i];
						items.push({
							key: "free:" + modelKey(row.providerId, row.modelId),
							kind: "model",
							row: row,
							providerId: row.providerId,
							modelId: row.modelId,
							effort: undefined,
						});
					}
			}
				for (let i = 0; i < view.groups.length; i += 1) {
					const group = view.groups[i];
					if (collapsedSet[group.providerId] === true) continue;
					for (let j = 0; j < group.rows.length; j += 1) {
						const row = group.rows[j];
						const selected =
							currentProviderId === row.providerId && currentModelId === row.modelId;
						items.push({
							key: "row:" + modelKey(row.providerId, row.modelId),
							kind: "model",
							row: row,
							providerId: row.providerId,
							modelId: row.modelId,
							effort: undefined,
						});
						if (!selected) continue;
						const choices = effortChoicesFor(row.model.reasoning, t);
						for (let k = 0; k < choices.length; k += 1) {
							items.push({
								key: "effort:" + modelKey(row.providerId, row.modelId) + "/" + effortKeyOf(choices[k].effort),
								kind: "effort",
								row: row,
								providerId: row.providerId,
								modelId: row.modelId,
								effort: choices[k].effort,
							});
						}
					}
				}
				return items;
			}, [view, collapsed, currentProviderId, currentModelId, t]);

			const navIndexByKey = React.useMemo(() => {
				const map = Object.create(null);
				for (let i = 0; i < nav.length; i += 1) map[nav[i].key] = i;
				return map;
			}, [nav]);

			let activeIndex = -1;
			if (activeId !== null) {
				for (let i = 0; i < nav.length; i += 1) {
					if (nav[i].key === activeId) {
						activeIndex = i;
						break;
					}
				}
			}

			/* ------------------------------------------------------------- 副作用 */

			// 首次拿到 provider 列表时把「除当前 provider 外全部折叠」写进 localStorage。
			React.useEffect(() => {
				if (seededRef.current) return;
				if (view.groups.length === 0) return;
				seededRef.current = true;
				if (hasStoredCollapsed()) return;
				const ids = [];
				for (let i = 0; i < view.groups.length; i += 1) {
					if (view.groups[i].providerId !== currentProviderId) ids.push(view.groups[i].providerId);
				}
				setCollapsed(ids);
				writeCollapsed(ids);
			}, [view, currentProviderId]);

			// 当前模型换了 provider（或本身就是免费模型）时自动展开它，否则用户在菜单里看不到选中项。
			React.useEffect(() => {
				if (!seededRef.current) return;
				const ids = [];
				if (currentProviderId !== null) ids.push(currentProviderId);
				// 免费分组的哨兵 id：当前模型是免费模型时同样要展开。
				const currentKey = currentProviderId !== null && currentModelId !== null ? modelKey(currentProviderId, currentModelId) : null;
				const currentFreeRow = currentKey !== null ? view.byKey[currentKey] : undefined;
				if (currentFreeRow !== undefined && currentFreeRow.freeHit !== undefined) ids.push(FREE_GROUP_ID);
				if (ids.length === 0) return;
				setCollapsed((previous) => {
					let next = previous;
					for (let i = 0; i < ids.length; i += 1) {
						if (next.indexOf(ids[i]) === -1) continue;
						next = next.filter((id) => id !== ids[i]);
					}
					if (next !== previous) writeCollapsed(next);
					return next;
				});
			}, [currentProviderId, currentModelId, view]);

			// 打开时把焦点交给搜索框（有）或菜单本身。
			React.useEffect(() => {
				if (open) POPUP_OPEN_COUNT += 1;
				if (!open) {
					setQuery("");
					setErrorText(null);
					setActiveId(null);
					return;
				}
				const search = searchRef.current;
				if (search !== null && search !== undefined && typeof search.focus === "function") {
					search.focus();
					return;
				}
				const node = itemRefs.current[activeIndex];
				if (node !== null && node !== undefined && typeof node.focus === "function") node.focus();
			}, [open]);

			// 弹层挂在 body 上，位置按触发器矩形实时夹进视口：先量自身尺寸再摆，
			// 量到之前保持隐藏（MEASURE_STYLE），避免在原点闪一下。
			React.useLayoutEffect(() => {
				if (!open) {
					setMenuPos(null);
					return undefined;
				}
				const place = () => {
					const root = rootRef.current;
					if (root === null || root === undefined || typeof root.getBoundingClientRect !== "function") return;
					const node = popupRef.current;
					const size =
						node !== null && node !== undefined
							? {
									width: typeof node.offsetWidth === "number" ? node.offsetWidth : 0,
									height: typeof node.offsetHeight === "number" ? node.offsetHeight : 0,
								}
							: { width: 0, height: 0 };
					const viewport =
						typeof window !== "undefined" && window !== null
							? { width: window.innerWidth, height: window.innerHeight }
							: { width: 0, height: 0 };
					const next = computeMenuPos(root.getBoundingClientRect(), size, viewport, MENU_MARGIN);
					setMenuPos((previous) =>
						previous !== null && previous.left === next.left && previous.top === next.top ? previous : next,
					);
				};
				place();
				if (typeof window === "undefined" || window === null || typeof window.addEventListener !== "function") {
					return undefined;
				}
				window.addEventListener("resize", place);
				window.addEventListener("scroll", place, true);
				const node = popupRef.current;
				const observer =
					typeof ResizeObserver !== "undefined" && node !== null && node !== undefined
						? new ResizeObserver(() => place())
						: null;
				if (observer !== null) observer.observe(node);
				return () => {
					window.removeEventListener("resize", place);
					window.removeEventListener("scroll", place, true);
					if (observer !== null) observer.disconnect();
				};
			}, [open]);

			// 打开后把活动项定位到当前模型。
			React.useEffect(() => {
				if (!open) return;
				if (nav.length === 0) {
					setActiveId(null);
					return;
				}
				let index = -1;
				for (let i = 0; i < nav.length; i += 1) {
					if (nav[i].kind !== "model") continue;
					if (nav[i].providerId === currentProviderId && nav[i].modelId === currentModelId) {
						index = i;
						break;
					}
				}
				setActiveId(nav[index === -1 ? 0 : index].key);
			}, [open]);

			// 活动项滚动进视口。
			React.useEffect(() => {
				if (!open) return;
				const node = itemRefs.current[activeIndex];
				if (node !== null && node !== undefined && typeof node.scrollIntoView === "function") {
					node.scrollIntoView({ block: "nearest" });
				}
			}, [open, activeIndex]);

			// Escape 关闭 + 点外部关闭。
			React.useEffect(() => {
				if (!open) return undefined;
				const onPointerDown = (event) => {
					const root = rootRef.current;
					if (root === null || root === undefined) return;
					const inside = typeof Node !== "undefined" && event.target instanceof Node;
					if (inside && root.contains(event.target)) return;
					// 弹层在 body 上，不在 root 子树里，必须单独判断。
					const popupNode = popupRef.current;
					if (inside && popupNode !== null && popupNode !== undefined && popupNode.contains(event.target)) return;
					setOpen(false);
				};
				const onKeyDown = (event) => {
					if (event.key !== "Escape") return;
					event.stopPropagation();
					setOpen(false);
					const trigger = triggerRef.current;
					if (trigger !== null && trigger !== undefined && typeof trigger.focus === "function") trigger.focus();
				};
				document.addEventListener("mousedown", onPointerDown, true);
				document.addEventListener("keydown", onKeyDown, true);
				return () => {
					document.removeEventListener("mousedown", onPointerDown, true);
					document.removeEventListener("keydown", onKeyDown, true);
				};
			}, [open]);

			/* --------------------------------------------------------------- 交互 */

			function choose(providerId, modelId, reasoningEffort) {
				if (!interactive) return;
				if (typeof select !== "function") {
					setErrorText(t("error.selectFailed"));
					return;
				}
				const selection = { provider: providerId, model: modelId };
				if (typeof reasoningEffort === "string") selection.reasoningEffort = reasoningEffort;
				setPendingId(modelKey(providerId, modelId));
				setErrorText(null);
				writeSelectDiag({ phase: "call", selection: selection });
				let result;
				try {
					result = select(selection);
				} catch (error) {
					setPendingId(null);
					setErrorText(describeError(error));
					writeSelectDiag({ phase: "sync-throw", selection: selection, message: String((error && error.message) || error), code: error && error.code, data: safeJson(error && error.data) });
					return;
				}
				Promise.resolve(result).then(
					(value) => {
						setPendingId(null);
						if (value !== null && typeof value === "object" && value.ok === false) {
							setErrorText(describeError(value.error));
							writeSelectDiag({ phase: "not-ok", selection: selection, message: String((value.error && value.error.message) || value.error), code: value.error && value.error.code, data: safeJson(value.error && value.error.data) });
							return;
						}
						writeSelectDiag({ phase: "ok", selection: selection, value: value === undefined ? "undefined" : safeJson(value) });
						setOpen(false);
						const trigger = triggerRef.current;
						if (trigger !== null && trigger !== undefined && typeof trigger.focus === "function") {
							trigger.focus();
						}
					},
					(error) => {
						setPendingId(null);
						setErrorText(describeError(error));
						writeSelectDiag({ phase: "reject", selection: selection, message: String((error && error.message) || error), code: error && error.code, data: safeJson(error && error.data) });
					},
				);
			}

			function toggleGroup(providerId) {
				setCollapsed((previous) => {
					const next =
						previous.indexOf(providerId) === -1
							? previous.concat([providerId])
							: previous.filter((id) => id !== providerId);
					writeCollapsed(next);
					return next;
				});
			}

			function move(delta) {
				if (nav.length === 0) return;
				const from = activeIndex === -1 ? (delta > 0 ? -1 : 0) : activeIndex;
				let next = from + delta;
				if (next < 0) next = nav.length - 1;
				if (next >= nav.length) next = 0;
				setActiveId(nav[next].key);
				const node = itemRefs.current[next];
				if (node !== null && node !== undefined && typeof node.focus === "function") node.focus();
			}

			function activate() {
				if (activeIndex === -1) return;
				const item = nav[activeIndex];
				if (item.kind === "model") {
					// Model-row click: never carry the current model's effort into another model
					// (server rejects unsupported efforts, e.g. "does not support reasoning effort \"High\"").
					// Omitting the field lets ModelDirectory.select apply the target model's default.
					choose(item.providerId, item.modelId);
					return;
				}
				choose(item.providerId, item.modelId, item.effort);
			}

			function onRootKeyDown(event) {
				if (!open) return;
				if (event.key === "ArrowDown") {
					event.preventDefault();
					move(1);
					return;
				}
				if (event.key === "ArrowUp") {
					event.preventDefault();
					move(-1);
					return;
				}
				if (event.key === "Home" && nav.length > 0) {
					event.preventDefault();
					setActiveId(nav[0].key);
					return;
				}
				if (event.key === "End" && nav.length > 0) {
					event.preventDefault();
					setActiveId(nav[nav.length - 1].key);
					return;
				}
				if (event.key === "Enter" || event.key === " ") {
					event.preventDefault();
					activate();
				}
			}

			function onTriggerKeyDown(event) {
				if (!interactive) return;
				if (event.key === "ArrowDown" || event.key === "ArrowUp" || event.key === "Enter" || event.key === " ") {
					event.preventDefault();
					setOpen(true);
				}
			}

			/* --------------------------------------------------------------- 渲染 */

			function renderTags(tags, limit, className) {
				if (tags.length === 0) return null;
				const children = [];
				const shown = tags.length > limit ? tags.slice(0, limit) : tags;
				for (let i = 0; i < shown.length; i += 1) {
					children.push(h("span", { className: className, key: "tag-" + i }, shown[i]));
				}
				return h("span", { className: "dmpp-tags" }, children);
			}

			function renderFreeBadge(freeHit) {
				if (freeHit === undefined) return null;
				const limited = freeHit.kind === "limited";
				const note = typeof freeHit.note === "string" && freeHit.note !== "" ? freeHit.note : undefined;
				return h(
					"span",
					{
						className: cx("dmpp-badge", limited ? "dmpp-badge-limited" : "dmpp-badge-free"),
						key: "free",
						title: note,
					},
					limited ? t("badge.limited") : t("badge.free"),
				);
			}

			function renderModelName(row, selected) {
				if (typeof renderSlot === "function") {
					try {
						const rendered = renderSlot(
							"conversation.input.model.label",
							{
								provider: row.provider,
								model: row.model,
								placement: "option",
								variant: "option",
								selected: selected,
							},
							{ fallback: row.model.name },
						);
						if (rendered !== undefined && rendered !== null && rendered !== false) return rendered;
					} catch (error) {
						// 其它 label 插槽不可用时退回纯文本，绝不因为装饰失败而崩掉菜单
					}
				}
				return typeof row.model.name === "string" && row.model.name !== "" ? row.model.name : row.modelId;
			}

			function isCurrentRow(row) {
				return currentProviderId === row.providerId && currentModelId === row.modelId;
			}

			function renderRow(row, keyPrefix) {
				const selected = isCurrentRow(row);
				const itemKey = keyPrefix + ":" + modelKey(row.providerId, row.modelId);
				const navIndex = navIndexByKey[itemKey];
				const isActive = activeId === itemKey;
				const busyRow = pendingId === modelKey(row.providerId, row.modelId);
				return h(
					"button",
					{
						key: itemKey,
						type: "button",
						role: "menuitemradio",
						"aria-checked": selected ? "true" : "false",
						tabIndex: isActive ? 0 : -1,
						className: cx("dmpp-option", selected && "is-selected", isActive && "is-active"),
						title: typeof row.model.name === "string" ? row.model.name : row.modelId,
						disabled: !interactive || busyRow,
						ref: (node) => {
							if (navIndex !== undefined) itemRefs.current[navIndex] = node;
						},
						onClick: () => choose(row.providerId, row.modelId),
						onMouseEnter: () => setActiveId(itemKey),
						onFocus: () => setActiveId(itemKey),
					},
					h(
						"span",
						{ className: "dmpp-option-main", key: "main" },
						h("span", { className: "dmpp-option-name", key: "name" }, renderModelName(row, selected)),
						renderTags(row.tags, ROW_TAG_LIMIT, "dmpp-tag"),
					),
					h(
						"span",
						{ className: "dmpp-option-side", key: "side" },
						renderFreeBadge(row.freeHit),
						h(
							"span",
							{ className: "dmpp-check", key: "check", "aria-hidden": "true" },
							busyRow ? h("span", { className: "dmpp-spinner" }) : selected ? "✓" : "",
						),
					),
				);
			}

			function renderEfforts(row) {
				const choices = effortChoicesFor(row.model.reasoning, t);
				if (choices.length === 0) return null;
				const chips = [];
				for (let i = 0; i < choices.length; i += 1) {
					const choice = choices[i];
					const itemKey =
						"effort:" + modelKey(row.providerId, row.modelId) + "/" + effortKeyOf(choice.effort);
					const navIndex = navIndexByKey[itemKey];
					const isActive = activeId === itemKey;
					const isSelected = choice.effort === effectiveEffort;
					chips.push(
						h(
							"button",
							{
								key: itemKey,
								type: "button",
								role: "menuitemradio",
								"aria-checked": isSelected ? "true" : "false",
								tabIndex: isActive ? 0 : -1,
								className: cx("dmpp-effort", isSelected && "is-selected", isActive && "is-active"),
								disabled: !interactive,
								ref: (node) => {
									if (navIndex !== undefined) itemRefs.current[navIndex] = node;
								},
								onClick: () => choose(row.providerId, row.modelId, choice.effort),
								onMouseEnter: () => setActiveId(itemKey),
								onFocus: () => setActiveId(itemKey),
							},
							choice.label,
						),
					);
				}
				const children = [h("span", { className: "dmpp-efforts-title", key: "title" }, t("effort.title"))];
				for (let i = 0; i < chips.length; i += 1) children.push(chips[i]);
				return h(
					"div",
					{ className: "dmpp-efforts", role: "group", "aria-label": t("effort.title"), key: "efforts" },
					children,
				);
			}

			function renderGroupHeader(group) {
				const isCollapsedGroup = collapsed.indexOf(group.providerId) !== -1;
				const count =
					txt === ""
						? String(group.modelCount)
						: String(group.rows.length) + "/" + String(group.modelCount);
				const action = isCollapsedGroup ? t("toggle.expand") : t("toggle.collapse");
				return h(
					"button",
					{
						key: "h:" + group.providerId,
						type: "button",
						role: "menuitem",
						disabled: !interactive,
						"aria-disabled": !interactive ? "true" : undefined,
						className: "dmpp-group-header",
						"aria-expanded": isCollapsedGroup ? "false" : "true",
						title: action + " " + group.providerName,
						onClick: () => toggleGroup(group.providerId),
					},
					h(
						"span",
						{
							className: cx("dmpp-arrow", !isCollapsedGroup && "is-open"),
							key: "arrow",
							"aria-hidden": "true",
						},
						"▸",
					),
					h("span", { className: "dmpp-group-name", key: "name" }, group.providerName),
					h(
						"span",
						{ className: "dmpp-group-count", key: "count" },
						count + " " + t("unit.models"),
					),
				);
			}

			const triggerName =
				currentRow !== undefined
					? typeof currentRow.model.name === "string" && currentRow.model.name !== ""
						? currentRow.model.name
						: currentRow.modelId
					: currentModelId !== null
						? currentModelId
						: t("trigger.empty");

			const triggerTags = currentRow !== undefined ? currentRow.tags : [];
			const triggerFree = currentRow !== undefined ? currentRow.freeHit : undefined;
			const readonlyLabel = !interactive
				? available
					? t("notice.locked")
					: t("notice.unavailable")
				: null;

			const triggerChildren = [
				h("span", { className: "dmpp-trigger-name", key: "name" }, triggerName),
				triggerTags.length > 0 ? renderTags(triggerTags, TRIGGER_TAG_LIMIT, "dmpp-trigger-tag") : null,
				renderFreeBadge(triggerFree),
				readonlyLabel !== null
					? h("span", { className: "dmpp-trigger-lock", key: "lock", title: readonlyLabel }, t("trigger.readonly"))
					: null,
				h("span", { className: "dmpp-caret", key: "caret", "aria-hidden": "true" }, "▾"),
			];

			const trigger = h(
				"button",
				{
					key: "trigger",
					ref: triggerRef,
					type: "button",
					className: "dmpp-trigger",
					disabled: !interactive,
					"aria-haspopup": "menu",
					"aria-expanded": open ? "true" : "false",
					"aria-controls": open ? menuId : undefined,
					"aria-label": triggerName,
					title: readonlyLabel !== null ? readonlyLabel : triggerName,
					onClick: () => {
						if (!interactive) return;
						setOpen((previous) => !previous);
					},
					onKeyDown: onTriggerKeyDown,
				},
				triggerChildren,
			);

			if (!open) return h("div", { className: cx("dmpp-root", !interactive && "is-locked"), ref: rootRef }, trigger);

			const popupChildren = [];

			if (!interactive) {
				popupChildren.push(
					h(
						"div",
						{ className: "dmpp-notice", key: "readonly" },
						available ? t("notice.locked") : t("notice.unavailable"),
					),
				);
			}

			if (state.status === "loading" && view.groups.length === 0) {
				popupChildren.push(h("div", { className: "dmpp-notice", key: "loading" }, t("state.loading")));
			}
			if (state.status === "error") {
				// 快照里的 error 可能是字符串、Error 实例或 { message }，都要取到文案。
				const rawError = state.error;
				const detail =
					typeof rawError === "string"
						? rawError
						: rawError !== null && rawError !== undefined && typeof rawError.message === "string"
							? rawError.message
							: "";
				popupChildren.push(
					h(
						"div",
						{ className: "dmpp-notice is-error", key: "error" },
						t("state.error") + (detail === "" ? "" : "：" + detail),
					),
				);
			}
			if (errorText !== null) {
				popupChildren.push(h("div", { className: "dmpp-notice is-error", key: "select-error" }, errorText));
			}

			if (totalModels > SEARCH_THRESHOLD) {
				popupChildren.push(
					h("input", {
						key: "search",
						ref: searchRef,
						type: "search",
						className: "dmpp-search",
						placeholder: t("search.placeholder"),
						"aria-label": t("search.placeholder"),
						value: query,
						onChange: (event) => setQuery(event.target.value),
						onKeyDown: (event) => {
							if (event.key === "ArrowDown" || event.key === "ArrowUp" || event.key === "Enter") {
								event.preventDefault();
								if (event.key === "Enter") activate();
								else move(event.key === "ArrowDown" ? 1 : -1);
							}
						},
					}),
				);
			}

			if (view.freeRows.length > 0) {
				const freeCollapsed = collapsed.indexOf(FREE_GROUP_ID) !== -1;
				const freeCount = String(view.freeRows.length);
				const freeAction = freeCollapsed ? t("toggle.expand") : t("toggle.collapse");
				const freeNodes = [
					h(
						"button",
						{
							key: "free-header",
							type: "button",
							role: "menuitem",
							disabled: !interactive,
							"aria-disabled": !interactive ? "true" : undefined,
							className: "dmpp-free-header",
							"aria-expanded": freeCollapsed ? "false" : "true",
							title: freeAction + " " + t("group.free"),
							onClick: () => toggleGroup(FREE_GROUP_ID),
						},
						h(
							"span",
							{ className: cx("dmpp-arrow", !freeCollapsed && "is-open"), key: "arrow", "aria-hidden": "true" },
							"▸",
						),
						h("span", { className: "dmpp-free-title", key: "title" }, t("group.free")),
						h("span", { className: "dmpp-free-count", key: "count" }, freeCount),
					),
				];
				if (!freeCollapsed) {
					for (let i = 0; i < view.freeRows.length; i += 1) {
						freeNodes.push(renderRow(view.freeRows[i], "free"));
					}
				}
				popupChildren.push(
					h("div", { className: "dmpp-section dmpp-section-free", key: "free" }, freeNodes),
				);
			}

			let visibleGroups = 0;
			for (let i = 0; i < view.groups.length; i += 1) {
				const group = view.groups[i];
				if (txt !== "" && group.rows.length === 0) continue;
				visibleGroups += 1;
				const isCollapsedGroup = collapsed.indexOf(group.providerId) !== -1;
				const nodes = [renderGroupHeader(group)];
				if (!isCollapsedGroup) {
					const bodyNodes = [];
					for (let j = 0; j < group.rows.length; j += 1) {
						const row = group.rows[j];
						bodyNodes.push(renderRow(row, "row"));
						if (isCurrentRow(row)) {
							const efforts = renderEfforts(row);
							if (efforts !== null) bodyNodes.push(efforts);
						}
					}
					if (bodyNodes.length > 0) {
						nodes.push(
							h(
								"div",
								{
									className: "dmpp-section-body",
									key: "body",
									role: "group",
									"aria-label": group.providerName,
								},
								bodyNodes,
							),
						);
					}
				}
				popupChildren.push(h("div", { className: "dmpp-section", key: "g:" + group.providerId }, nodes));
			}

			if (view.groups.length === 0 && state.status !== "loading" && state.status !== "error") {
				popupChildren.push(h("div", { className: "dmpp-notice", key: "empty" }, t("state.empty")));
			} else if (txt !== "" && visibleGroups === 0 && view.freeRows.length === 0) {
				popupChildren.push(h("div", { className: "dmpp-notice", key: "nomatch" }, t("state.noMatch")));
			}

			const popup = h(
				"div",
				{
					key: "popup",
					id: menuId,
					ref: popupRef,
					className: "dmpp-popup",
					style:
						menuPos !== null
							? { left: String(menuPos.left) + "px", top: String(menuPos.top) + "px" }
							: MEASURE_STYLE,
					role: "menu",
					"aria-label": t("menu.label"),
					// 弹层已挂到 body，root 上的键盘处理接不到它，必须在这里再挂一次。
					onKeyDown: onRootKeyDown,
				},
				popupChildren,
			);

			// 挂到 body：祖先容器的 overflow/圆角裁不到它，也才能按视口坐标摆放。
			const popupPortal =
				ReactDOM !== null &&
				typeof ReactDOM.createPortal === "function" &&
				typeof document !== "undefined" &&
				document !== null &&
				document.body !== null &&
				document.body !== undefined
					? ReactDOM.createPortal(popup, document.body)
					: popup;

			return h(
				"div",
				{ className: cx("dmpp-root", !interactive && "is-locked", "is-open"), ref: rootRef, onKeyDown: onRootKeyDown },
				trigger,
				popupPortal,
			);
		}

		/* ------------------------------------------------------ 插槽抢占辅助函数 */
		
		// 已经注册的 options.name 集合，用来把「别人」的条目从条目列表里区分出来。
		// 我们自己注册过的 options / component 引用，用来把「别人」的条目区分出来。
		const OWN_SLOT_OPTIONS = [];
		let LAST_SLOT_SCOPE = null;
		let LAST_SLOT_OPTIONS = null;
		
		function isOwnEntry(entry) {
			if (entry === null || entry === undefined) return false;
			if (entry.component === ModelSelectPlus) return true;
			const options = entry.options;
			if (options === null || options === undefined) return false;
			for (let i = 0; i < OWN_SLOT_OPTIONS.length; i += 1) {
				if (OWN_SLOT_OPTIONS[i] === options) return true;
			}
			return false;
		}
		
		function readEntries(scope) {
			try {
				if (scope === null || scope === undefined) return null;
				const slots = scope.slots;
				if (slots === null || slots === undefined) return null;
				if (typeof slots.entries !== "function") return null;
				const list = slots.entries(SLOT_NAME);
				return Array.isArray(list) ? list : null;
			} catch (error) {
				return null;
			}
		}
		
		function entryPriority(entry) {
			if (entry === null || entry === undefined) return 0;
			const options = entry.options;
			const raw = options !== null && typeof options === "object" ? options.priority : undefined;
			if (typeof raw === "number" && isFinite(raw)) return raw;
			const flat = entry.priority;
			return typeof flat === "number" && isFinite(flat) ? flat : 0;
		}
		
		// 在自己尚未注册时调用：返回现存条目里最小的 priority（没有则 null）。
		function lowestOtherPriority(scope) {
			try {
				const entries = readEntries(scope);
				if (entries === null) return null;
				let lowest = null;
				for (let i = 0; i < entries.length; i += 1) {
					const entry = entries[i];
					if (isOwnEntry(entry)) continue;
					const priority = entryPriority(entry);
					if (lowest === null || priority < lowest.priority) lowest = { priority: priority };
				}
				return lowest;
			} catch (error) {
				return null;
			}
		}
		
		// 已注册之后：只看比我们小的，用来判断有没有被 shadow。
		function lowestBelow(scope, mine) {
			try {
				const entries = readEntries(scope);
				if (entries === null) return null;
				let lowest = null;
				for (let i = 0; i < entries.length; i += 1) {
					const entry = entries[i];
					if (isOwnEntry(entry)) continue;
					const priority = entryPriority(entry);
					if (priority >= mine) continue;
					if (lowest === null || priority < lowest) lowest = priority;
				}
				return lowest;
			} catch (error) {
				return null;
			}
		}
		
		function snapshotEntries(scope) {
			const out = [];
			try {
				const entries = readEntries(scope);
				if (entries === null) return out;
				for (let i = 0; i < entries.length; i += 1) {
					const entry = entries[i];
					const options = entry === null || entry === undefined ? undefined : entry.options;
					const safe = options === null || typeof options !== "object" ? {} : options;
					out.push({
						priority: entryPriority(entry),
						locale: typeof safe.locale === "string" ? safe.locale : null,
						hasInject: typeof safe.inject === "function",
					});
				}
			} catch (error) {
				// 快照失败就返回已收集到的部分
			}
			return out;
		}
		
		/* -------------------------------------------------------------- 插槽注册 */

		function apply(ctx) {
			// 取证第一优先：进入 apply 立刻落盘，与组件是否挂载无关。
			try {
				let ua = null;
				if (typeof navigator !== "undefined" && navigator !== null && typeof navigator.userAgent === "string") {
					ua = navigator.userAgent.slice(0, 60);
				}
				window.localStorage.setItem(
					BOOT_KEY,
					JSON.stringify({ v: 2, stage: "apply", at: Date.now(), inject: String(inject), ua: ua }),
				);
			} catch (error) {
				// 埋点失败静默
			}
			ensureStyle();

			ctx.effect(() => ctx.locale.register(NS, DICTIONARIES), "dsh-model-picker-plus: dictionaries");

			// 关键：声明 remote / remote.session。cordis 的 service traceable 会把方法调用
		// 绑定到「拿到 service 的那个模块」的 ctx 上：ModelDirectoryResolver.directoryFor 构造
		// ModelDirectory 时经 this.ctx.remote.session 取远程服务，解析走本模块的 inject 链——
		// 未声明就会抛 "cannot get property \"remote.session\" without inject"（冷启动必现；
		// 暖启动只是 live.directories 缓存命中才侥幸不触发）。
		ctx.inject(["slots", "modelDirectories", "sessions", "remote", "remote.session"], (scope) => {
				const safeScope = scope === null || scope === undefined ? {} : scope;
				APPLY_DIAG = {
					v: 2,
					stage: "applied",
					at: Date.now(),
					hasSlots: safeScope.slots !== null && safeScope.slots !== undefined,
					hasModelDirectories: safeScope.modelDirectories !== null && safeScope.modelDirectories !== undefined,
					hasSessions: safeScope.sessions !== null && safeScope.sessions !== undefined,
					hasInject: typeof safeScope.inject === "function",
					hasEffect: typeof safeScope.effect === "function",
					registered: null,
					rounds: 0,
					lowestBelow: null,
					weLowest: false,
				};
				writeApplyDiag();
				const models = scope.modelDirectories;
				const sessions = scope.sessions;

				// 会话绑定就绪前 directoryFor 会抛错（重启恢复会话时的竞态）。
				// 惰性重试 facade：轮询 directoryFor，一旦成功就把订阅与快照转发给真实 store，
				// 避免把空 store 永久固化进本次挂载。
				function createRetryingDirectory(sessionId) {
					let real = null;
					let realUnsub = null;
					const listeners = new Set();
					let timer = null;
					let tries = 0;
					let facadeError = "not tried";
					const notify = () => {
						for (const fn of Array.from(listeners)) {
							try {
								fn();
							} catch (error) {}
						}
					};
					const resolve = () => {
						if (real !== null) return true;
						try {
							const candidate = models.directoryFor(sessionId);
							if (candidate !== null && candidate !== undefined && candidate.store !== undefined) {
								real = candidate;
								return true;
							}
							facadeError = "directoryFor returned " + String(candidate);
						} catch (error) {
							facadeError = String((error && error.message) || error);
						}
						return false;
					};
					const pump = () => {
						if (resolve() && realUnsub === null) {
							realUnsub = real.store.subscribe(notify);
							if (timer !== null) {
								clearInterval(timer);
								timer = null;
							}
							writeRetryDiag({ phase: "resolved", session: String(sessionId).slice(-12), tries: tries, message: "" });
							notify();
						}
					};
					return {
						subscribe: (fn) => {
							listeners.add(fn);
							if (real === null && timer === null) {
								// 前 150 轮 400ms 快速重试；之后降频到 4s 永久轮询（永不放弃：会话 binding
								// 可能晚于挂载很久才就绪，例如重启后恢复的会话，用户开始输入时才建好）。
								timer = setInterval(() => {
									tries += 1;
									pump();
									if (real !== null) {
										clearInterval(timer);
										timer = null;
									} else {
										if (tries % 5 === 1) writeRetryDiag({ phase: "poll", session: String(sessionId).slice(-12), tries: tries, message: facadeError });
										if (tries >= 150) {
											clearInterval(timer);
											timer = setInterval(pump, 4000);
										}
									}
								}, 400);
							}
							pump();
							if (real === null) writeRetryDiag({ phase: "subscribe", session: String(sessionId).slice(-12), tries: tries, message: facadeError });
							return () => {
								listeners.delete(fn);
								if (listeners.size === 0 && realUnsub !== null) {
									realUnsub();
									realUnsub = null;
								}
							};
						},
						getSnapshot: () => (real !== null ? real.store.getSnapshot() : EMPTY_SNAPSHOT),
						real: () => real,
					};
				}

				function bootstrap(sessionId) {
					if (
						models === null ||
						models === undefined ||
						typeof models.directoryFor !== "function"
					) {
						return { available: false, directory: createEmptyStore(), load: () => {}, select: () => Promise.resolve(undefined) };
					}
					const available =
						sessions === null || sessions === undefined || typeof sessions.subagentAddress !== "function"
							? true
							: sessions.subagentAddress(sessionId) === undefined;
					let directory;
					try {
						directory = models.directoryFor(sessionId);
					} catch (error) {
						directory = undefined;
						writeRetryDiag({ phase: "bootstrap", session: String(sessionId).slice(-12), tries: 0, message: String((error && error.message) || error) });
					}
					if (directory === null || directory === undefined || directory.store === undefined) {
						// 会话绑定尚未就绪：用惰性重试 facade 顶上，绑定就绪后自动切换到真实 store。
						const facade = createRetryingDirectory(sessionId);
						return {
							available: available,
							directory: facade,
							load: () => {
								if (!available) return;
								const target = facade.real();
								if (target !== null) target.load().catch(() => {});
							},
							select: (selection) => {
								if (!available) return Promise.resolve(undefined);
								const target = facade.real();
								return target !== null ? target.select(selection) : Promise.resolve(undefined);
							},
						};
					}
					return {
						available: available,
						directory: directory.store,
						load: () => {
							if (available) directory.load().catch(() => {});
						},
						select: (selection) =>
							available ? directory.select(selection) : Promise.resolve(undefined),
					};
				}

				// 抢占插槽：ds-bot 之类会用 freePriority 反超任何静态优先级，
				// 所以注册前先读现存条目，把 priority 压到「比所有人都小」。
				let watchdogTimer = null;
				let watchdogRounds = 0;
				
				function buildOptions(priority) {
					return {
						name: SLOT_NAME,
						priority: priority,
						locale: NS,
						inject: bootstrap,
					};
				}
				
				function nextPriority(scope) {
					let priority = FALLBACK_PRIORITY;
					try {
						const lowest = lowestOtherPriority(scope);
						if (lowest !== null && lowest.priority - 1 < priority) priority = lowest.priority - 1;
					} catch (error) {
						priority = FALLBACK_PRIORITY;
					}
					return priority;
				}
				
				function registerSlot(priority) {
					const options = buildOptions(priority);
					OWN_SLOT_OPTIONS.push(options);
					REGISTERED_PRIORITY = priority;
					LAST_SLOT_SCOPE = scope;
					LAST_SLOT_OPTIONS = options;
					scope.slots.register(options, ModelSelectPlus);
					// 注册成功后立刻回填埋点：首轮注册后 apply 键就带 registered，
					// 不必等看门狗第一轮才落盘。
					if (APPLY_DIAG !== null) {
						APPLY_DIAG.registered = priority;
						writeApplyDiag();
					}
				}
				
				function stopWatchdog() {
					if (watchdogTimer !== null) {
						if (typeof clearTimeout === "function") clearTimeout(watchdogTimer);
						if (typeof clearInterval === "function") clearInterval(watchdogTimer);
					}
					watchdogTimer = null;
				}
				
				// 每轮都要落盘：被抢占时组件根本不挂载，只有这里有据可查。
				function watchdog() {
					try {
						watchdogRounds += 1;
						const mine = REGISTERED_PRIORITY;
						const below = mine === null ? null : lowestBelow(scope, mine);
						if (APPLY_DIAG !== null) {
							APPLY_DIAG.rounds = watchdogRounds;
							APPLY_DIAG.registered = mine;
							APPLY_DIAG.lowestBelow = below;
							APPLY_DIAG.weLowest = mine !== null && below === null;
							writeApplyDiag();
						}
						if (mine === null || below === null) return;
						registerSlot(below - 1);
					} catch (error) {
						// 单轮失败只跳过这一轮，看门狗永不退场
					}
				}
				
				// 前 20 轮 600ms 快速反超，之后 4000ms 长期蹲守（页面卸载才停）。
				function scheduleWatchdog() {
					if (typeof setTimeout !== "function") return;
					const delay = watchdogRounds < WATCHDOG_FAST_ROUNDS ? WATCHDOG_FAST_INTERVAL : WATCHDOG_SLOW_INTERVAL;
					watchdogTimer = setTimeout(() => {
						watchdog();
						scheduleWatchdog();
					}, delay);
				}
				
				try {
					const priority = nextPriority(scope);
					registerSlot(priority);
					scheduleWatchdog();
				} catch (error) {
					// 注册失败也不能让整个插件挂掉
					try {
						scope.slots.register(buildOptions(FALLBACK_PRIORITY), ModelSelectPlus);
					} catch (inner) {
						// 彻底放弃
					}
				}
			});
		}

		const inject = ["slots", "locale", "modelDirectories", "sessions"];

		exports.apply = apply;
		exports.inject = inject;
		exports.ModelSelectPlus = ModelSelectPlus;
		// 仅供 scripts/verify-slot.mjs 离线断言使用，宿主不会读它。
		exports.__internals = { computeMenuPos: computeMenuPos };
		return module.exports;
	},
});
