/**
 * dsh-model-picker-plus - 离线自证脚本（只用 node 内置模块）。
 *
 * 用假 window / 假 require 执行 client.js 的 factory，断言：
 *   a) exports 形状与 inject 列表；
 *   b) 只调 apply、不让任何组件挂载，apply 级埋点也必须落盘；
 *   c/d) 不同现存条目下的首轮 priority；
 *   e) ds-bot 塞入 -1000000 后，看门狗能反超，rounds 递增，weLowest 最终为 true；
 *   f) 整个过程顶层不抛异常。
 *   g) 真正调用组件函数（useEffect 同步执行的 react stub），渲染期不抛异常且 diag 落盘。
 */
import { readFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(HERE, "..");
const CLIENT = join(ROOT, "client.js");

let FAILURES = 0;
function assert(ok, label, extra) {
	if (ok) {
		console.log("PASS  " + label + (extra === undefined ? "" : " :: " + extra));
	} else {
		FAILURES += 1;
		console.log("FAIL  " + label + (extra === undefined ? "" : " :: " + extra));
	}
}

/* ------------------------------------------------------------ 假 localStorage */

function createStorage() {
	const map = new Map();
	return {
		map: map,
		getItem: (k) => (map.has(String(k)) ? map.get(String(k)) : null),
		setItem: (k, v) => {
			map.set(String(k), String(v));
		},
		removeItem: (k) => {
			map.delete(String(k));
		},
		clear: () => map.clear(),
		key: (i) => Array.from(map.keys())[i] ?? null,
		get length() {
			return map.size;
		},
	};
}

/* ----------------------------------------------------------- 假 react / jsx */

function fakeComponent(tag) {
	const fn = () => null;
	fn.displayName = "fake:" + String(tag);
	return fn;
}

// executeEffects=true 时 useEffect 立即同步执行回调（模拟挂载），
// 用来让组件函数真正跑一遍，抓渲染期崩溃（TDZ 等）；其它场景仍用 noop stub。
function createReact(executeEffects) {
	const noop = () => {};
	const handler = {
		get(_target, prop) {
			if (prop === "createElement") return (...args) => ({ type: args[0], props: args[1] ?? null });
			if (prop === "Fragment") return Symbol.for("react.fragment");
			if (prop === "useState") return (init) => [typeof init === "function" ? init() : init, noop];
			if (prop === "useEffect") {
				return executeEffects === true
					? (fn) => {
							try {
								fn();
							} catch (error) {
								throw error;
							}
						}
					: noop;
			}
			if (prop === "useLayoutEffect") return noop;
			if (prop === "useRef") return (init) => ({ current: init === undefined ? null : init });
			if (prop === "useMemo") return (factory) => factory();
			if (prop === "useCallback") return (fn) => fn;
			if (prop === "useSyncExternalStore") return (_sub, get) => (typeof get === "function" ? get() : null);
			if (prop === "useReducer") return (init) => [init, noop];
			if (prop === "useContext") return () => null;
			if (prop === "useImperativeHandle") return noop;
			if (prop === "forwardRef") return (render) => render;
			if (prop === "memo") return (c) => c;
			if (prop === "createContext") return () => ({ Provider: fakeComponent("Provider"), Consumer: fakeComponent("Consumer") });
			if (typeof prop === "symbol") return undefined;
			return fakeComponent(prop);
		},
	};
	return new Proxy({}, handler);
}

function createJsxRuntime() {
	return {
		Fragment: Symbol.for("react.fragment"),
		jsx: (type, props) => ({ type: type, props: props ?? null }),
		jsxs: (type, props) => ({ type: type, props: props ?? null }),
	};
}

/* ------------------------------------------------------------ 假定时器驱动 */

function createClock() {
	let seq = 0;
	let now = 0;
	const pending = new Map();
	return {
		pending: pending,
		get size() {
			return pending.size;
		},
		setTimeout: (fn, delay) => {
			seq += 1;
			pending.set(seq, { fn: fn, at: now + (Number(delay) || 0) });
			return seq;
		},
		setInterval: (fn, delay) => {
			seq += 1;
			pending.set(seq, { fn: fn, at: now + (Number(delay) || 0), every: Number(delay) || 0 });
			return seq;
		},
		clearTimeout: (id) => {
			pending.delete(id);
		},
		clearInterval: (id) => {
			pending.delete(id);
		},
		// 推进 ms 毫秒，按到期顺序执行；返回本轮执行的回调数。
		tick(ms) {
			const target = now + ms;
			let ran = 0;
			for (;;) {
				let nextId = null;
				let next = null;
				for (const [id, t] of pending) {
					if (t.at <= target && (next === null || t.at < next.at)) {
						nextId = id;
						next = t;
					}
				}
				if (nextId === null) break;
				now = next.at;
				if (next.every) {
					next.at = now + next.every;
				} else {
					pending.delete(nextId);
				}
				next.fn();
				ran += 1;
				if (ran > 10000) throw new Error("定时器失控：单轮执行超过 10000 次");
			}
			now = target;
			return ran;
		},
	};
}

/* -------------------------------------------------------- 假 slots / window */

function createSlots(entriesRef) {
	return {
		register: (options, component) => {
			entriesRef.list.push({ options: options, component: component });
		},
		entries: (name) => (name === "conversation.input.model" ? entriesRef.list.slice() : []),
	};
}

function createFakeWindow(storage, clock, entriesRef) {
	const listeners = { mousedown: [], keydown: [] };
	const win = {
		localStorage: storage,
		__ModuleLoader__: {
			load: (desc) => {
				win.__factory__ = desc.factory;
				win.__desc__ = desc;
			},
		},
		navigator: { userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) verify-slot-harness-ua-padding-0123456789" },
		setTimeout: clock.setTimeout,
		setInterval: clock.setInterval,
		clearTimeout: clock.clearTimeout,
		clearInterval: clock.clearInterval,
		addEventListener: () => {},
		removeEventListener: () => {},
		requestAnimationFrame: (fn) => clock.setTimeout(fn, 16),
		cancelAnimationFrame: (id) => clock.clearTimeout(id),
		matchMedia: () => ({ matches: false, addEventListener: () => {}, removeEventListener: () => {} }),
		document: {
			listeners: listeners,
			head: { appendChild: () => {} },
			body: { appendChild: () => {} },
			querySelector: () => null,
			createElement: (tagName) => ({ tagName: tagName, setAttribute: () => {}, textContent: "", appendChild: () => {}, style: {}, dataset: {} }),
			documentElement: { style: {} },
			addEventListener: (type, fn) => {
				if (listeners[type] === undefined) listeners[type] = [];
				listeners[type].push(fn);
			},
			removeEventListener: (type, fn) => {
				if (listeners[type] === undefined) return;
				listeners[type] = listeners[type].filter((entry) => entry !== fn);
			},
			contains: () => false,
		},
	};
	win.documentListeners = listeners;
	win.window = win;
	return win;
}

/* ------------------------------------------------------------------ 加载 */

const code = readFileSync(CLIENT, "utf8");
const storage = createStorage();
const clock = createClock();
const entriesRef = { list: [] };
const win = createFakeWindow(storage, clock, entriesRef);
const reactStub = createReact();
const jsxStub = createJsxRuntime();
// 弹层走 createPortal；离线环境里直接返回节点，便于继续遍历。
const reactDomStub = { createPortal: (node) => node, version: "18.0.0" };
const consoleStub = { log: () => {}, warn: () => {}, error: () => {}, info: () => {}, debug: () => {} };

// client.js 里存在裸全局（navigator / setTimeout / clearTimeout / setInterval /
// clearInterval / localStorage / requestAnimationFrame / cancelAnimationFrame），
// 浏览器里它们等价于 window.*，但这里用 new Function 执行时会落到 Node 全局，
// 所以必须逐个注入假实现，否则看门狗/埋点走的是真定时器且读不到假 navigator。
const loader = new Function(
	"window",
	"console",
	"navigator",
	"localStorage",
	"setTimeout",
	"clearTimeout",
	"setInterval",
	"clearInterval",
	"requestAnimationFrame",
	"cancelAnimationFrame",
	code,
);
loader(
	win,
	consoleStub,
	win.navigator,
	storage,
	clock.setTimeout,
	clock.clearTimeout,
	clock.setInterval,
	clock.clearInterval,
	win.requestAnimationFrame,
	win.cancelAnimationFrame,
);
assert(typeof win.__factory__ === "function", "a0) window.__ModuleLoader__.load 抓到 factory");

const fakeRequire = (id) => {
	if (id === "react") return reactStub;
	if (id === "react/jsx-runtime") return jsxStub;
		if (id === "react-dom") return reactDomStub;
	throw new Error("未预期的 require: " + id);
};

const exports_ = win.__factory__(fakeRequire);

console.log("\n=== a) exports 形状 ===");
const keys = Object.keys(exports_);
console.log("exports keys: " + JSON.stringify(keys));
assert(typeof exports_.apply === "function", "a1) exports.apply 是函数");
assert(typeof exports_.ModelSelectPlus !== "undefined", "a2) exports.ModelSelectPlus 存在");
const expectedInject = ["slots", "locale", "modelDirectories", "sessions"];
console.log("exports.inject: " + JSON.stringify(exports_.inject));
assert(
	Array.isArray(exports_.inject) &&
		exports_.inject.length === expectedInject.length &&
		exports_.inject.every((v, i) => v === expectedInject[i]),
	"a3) inject 严格等于 [slots, locale, modelDirectories, sessions]",
);

/* ------------------------------------------------- 构造 ctx（slots.inject 空实现） */

function createCtx(slots, extraEntries) {
	entriesRef.list = extraEntries === undefined ? [] : extraEntries.slice();
	const scope = {
		slots: slots,
		locale: { register: () => () => {}, t: (k) => String(k) },
		modelDirectories: { directoryFor: () => undefined },
		sessions: { subagentAddress: () => undefined },
		inject: (deps, fn) => {
			// 记账但不执行组件相关副作用；apply 的注册回调由本脚本显式驱动。
			scope.__injected = scope.__injected || [];
			scope.__injected.push({ deps: deps, fn: fn });
		},
		effect: (fn) => {
			scope.__effects = scope.__effects || [];
			scope.__effects.push(fn);
		},
	};
	return {
		scope: scope,
		ctx: {
			locale: scope.locale,
			effect: scope.effect,
			inject: scope.inject,
		},
	};
}

function resolveInjects(scope) {
	const rootScope = Object.assign({}, scope);
	// apply 用的是 ctx.inject([...], cb)，直接把 rootScope 交给回调（含 slots 自身）。
	const list = scope.__injected || [];
	for (const item of list) {
		item.fn(rootScope);
	}
	return rootScope;
}

console.log("\n=== b) 只调 apply，不让组件挂载 ===");
{
	storage.clear();
	clock.pending.clear();
	const slots = createSlots(entriesRef);
	const built = createCtx(slots, []);
	let threw = null;
	try {
		exports_.apply(built.ctx);
		resolveInjects(built.scope);
	} catch (error) {
		threw = error;
	}
	assert(threw === null, "b0) apply 未抛异常", threw === null ? "" : String(threw && threw.stack));
	const boot = storage.getItem("dsh.modelPickerPlus.boot");
	const applyDiag = storage.getItem("dsh.modelPickerPlus.apply");
	assert(boot !== null, "b1) dsh.modelPickerPlus.boot 已写入（未挂载组件）");
	assert(applyDiag !== null, "b2) dsh.modelPickerPlus.apply 已写入（未挂载组件）");
	console.log("dsh.modelPickerPlus.boot  = " + String(boot));
	console.log("dsh.modelPickerPlus.apply = " + String(applyDiag));
	if (boot !== null) {
		const p = JSON.parse(boot);
		assert(p.v === 2 && p.stage === "apply", "b3) boot payload v=2 / stage=apply");
		assert(
			p.inject === "slots,locale,modelDirectories,sessions",
			"b4) boot.inject 是 inject 数组的字符串形式",
			String(p.inject),
		);
		assert(typeof p.ua === "string" && p.ua.length === 60, "b5) boot.ua 取前 60 字符", String(p.ua));
	}
	if (applyDiag !== null) {
		const p = JSON.parse(applyDiag);
		assert(p.v === 2 && p.stage === "applied", "b6) apply payload v=2 / stage=applied");
		assert(p.hasSlots === true && p.hasModelDirectories === true && p.hasSessions === true, "b7) scope 三项齐备");
		assert(p.hasInject === true && p.hasEffect === true, "b8) hasInject / hasEffect 为 true");
		assert(p.registered === null || typeof p.registered === "number", "b9) registered 已填", String(p.registered));
	}
}

console.log("\n=== c) 场景 A：现存 [{priority:0}] ===");
{
	storage.clear();
	clock.pending.clear();
	const slots = createSlots(entriesRef);
	const built = createCtx(slots, [{ options: { priority: 0 } }]);
	let threw = null;
	try {
		exports_.apply(built.ctx);
		resolveInjects(built.scope);
	} catch (error) {
		threw = error;
	}
	assert(threw === null, "c0) 未抛异常", threw === null ? "" : String(threw && threw.stack));
	const p = JSON.parse(storage.getItem("dsh.modelPickerPlus.apply"));
	console.log("apply = " + JSON.stringify(p));
	assert(p.registered === -1000, "c1) 首轮注册 priority = -1000", String(p.registered));
	// entriesRef.list 含预置条目，所以只数「我们自己的注册」：
	// name === "conversation.input.model" 且 component === exports_.ModelSelectPlus。
	const own = entriesRef.list.filter(
		(e) => e.options.name === "conversation.input.model" && e.component === exports_.ModelSelectPlus,
	);
	assert(own.length === 1, "c2) slots.register 被调用一次（仅计本插件注册）", "own=" + own.length + " total=" + entriesRef.list.length);
}

console.log("\n=== d) 场景 B：现存 [{priority:0},{priority:-100}] ===");
{
	storage.clear();
	clock.pending.clear();
	const slots = createSlots(entriesRef);
	const built = createCtx(slots, [{ options: { priority: 0 } }, { options: { priority: -100 } }]);
	let threw = null;
	try {
		exports_.apply(built.ctx);
		resolveInjects(built.scope);
	} catch (error) {
		threw = error;
	}
	assert(threw === null, "d0) 未抛异常", threw === null ? "" : String(threw && threw.stack));
	const p = JSON.parse(storage.getItem("dsh.modelPickerPlus.apply"));
	console.log("apply = " + JSON.stringify(p));
	assert(p.registered === -1000, "d1) 首轮注册 priority = -1000（-100 之上仍有余量）", String(p.registered));
}

console.log("\n=== e) 场景 C：ds-bot 塞入 -1000000，推进定时器 ===");
{
	storage.clear();
	clock.pending.clear();
	const slots = createSlots(entriesRef);
	const built = createCtx(slots, []);
	let threw = null;
	try {
		exports_.apply(built.ctx);
		resolveInjects(built.scope);
	} catch (error) {
		threw = error;
	}
	assert(threw === null, "e0) 首轮注册未抛异常", threw === null ? "" : String(threw && threw.stack));
	console.log("round 0 (首轮注册)  apply = " + storage.getItem("dsh.modelPickerPlus.apply"));

	// ds-bot 抢注：freePriority = Math.min(-100, ...现存各条 priority - 1)
	const before = entriesRef.list.slice();
	const dsBot = { options: { priority: -1000000, name: "conversation.input.model" } };
	entriesRef.list = before.concat([dsBot]);
	console.log("注入 ds-bot 条目 priority=-1000000，当前条目数 = " + entriesRef.list.length);

	const rounds = [];
	let prevRounds = 0;
	for (let i = 1; i <= 6; i += 1) {
		let tickError = null;
		try {
			clock.tick(600);
		} catch (error) {
			tickError = error;
		}
		assert(tickError === null, "e1." + i + ") 推进定时器未抛异常", tickError === null ? "" : String(tickError && tickError.stack));
		const raw = storage.getItem("dsh.modelPickerPlus.apply");
		console.log("round " + i + "  apply = " + raw);
		const p = JSON.parse(raw);
		rounds.push(p);
		assert(p.rounds > prevRounds, "e2." + i + ") rounds 递增", prevRounds + " -> " + p.rounds);
		prevRounds = p.rounds;
	}

	const last = rounds[rounds.length - 1];
	console.log("最终 registrations: " + JSON.stringify(entriesRef.list.map((e) => e.options.priority)));
	assert(last.registered <= -1000001, "e3) 最终注册 priority <= -1000001", String(last.registered));
	assert(last.weLowest === true, "e4) 最终 weLowest = true", String(last.weLowest));
	assert(last.lowestBelow === null, "e5) 最终 lowestBelow = null（已无更低者）", String(last.lowestBelow));
	assert(clock.size > 0, "e6) 看门狗仍在排队（未过早停火）", "pending=" + clock.size);
}

console.log("\n=== 假 localStorage 收集到的全部键值 ===");
{
	storage.clear();
	clock.pending.clear();
	const slots = createSlots(entriesRef);
	const built = createCtx(slots, [{ options: { priority: 0 } }]);
	exports_.apply(built.ctx);
	resolveInjects(built.scope);
	clock.tick(2000);
	for (const [k, v] of storage.map) {
		console.log(k + " = " + v);
	}
}

console.log("\n=== g) 场景 D：真正调用组件函数（挂载）===");
{
	// 重新加载 client.js，配一个「useEffect 会同步执行回调」的 react stub：
	// 原 stub 的 useEffect 是 noop，从不执行 effect 回调，所以渲染期崩溃（TDZ）测不出来。
	storage.clear();
	clock.pending.clear();
	entriesRef.list = [];
	const winG = createFakeWindow(storage, clock, entriesRef);
	const loaderG = new Function(
		"window",
		"console",
		"navigator",
		"localStorage",
		"setTimeout",
		"clearTimeout",
		"setInterval",
		"clearInterval",
		"requestAnimationFrame",
		"cancelAnimationFrame",
		code,
	);
	loaderG(
		winG,
		consoleStub,
		winG.navigator,
		storage,
		clock.setTimeout,
		clock.clearTimeout,
		clock.setInterval,
		clock.clearInterval,
		winG.requestAnimationFrame,
		winG.cancelAnimationFrame,
	);
	const reactG = createReact(true);
	const requireG = (id) => {
		if (id === "react") return reactG;
		if (id === "react/jsx-runtime") return jsxStub;
		if (id === "react-dom") return reactDomStub;
		throw new Error("未预期的 require: " + id);
	};
	const exportsG = winG.__factory__(requireG);

	// 先跑一遍 apply + 注册，让 LAST_SLOT_SCOPE / LAST_SLOT_OPTIONS / APPLY_DIAG 就位。
	const slots = createSlots(entriesRef);
	const built = createCtx(slots, []);
	let applyThrew = null;
	try {
		exportsG.apply(built.ctx);
		resolveInjects(built.scope);
	} catch (error) {
		applyThrew = error;
	}
	assert(applyThrew === null, "g0) apply 未抛异常", applyThrew === null ? "" : String(applyThrew && applyThrew.stack));

	const snapshot = {
		status: "ready",
		error: null,
		groups: [
			{
				id: "p1",
				name: "P1",
				models: [
					{ id: "m1", name: "M1" },
					{ id: "m2", name: "M2", reasoning: { defaultEffort: "high", default: true } },
				],
			},
		],
		failures: [],
		current: { provider: "p1", model: "m1" },
		default: { provider: "p1", model: "m1" },
	};
	const props = {
		locked: false,
		available: true,
		directory: {
			subscribe: () => () => {},
			getSnapshot: () => snapshot,
		},
		select: () => Promise.resolve({ ok: true }),
		t: (k) => String(k),
		renderSlot: undefined,
	};

	let renderThrew = null;
	try {
		exportsG.ModelSelectPlus(props);
	} catch (error) {
		renderThrew = error;
	}
	assert(renderThrew === null, "g1) 组件渲染未抛异常", renderThrew === null ? "" : String(renderThrew && renderThrew.message));

	const diagRaw = storage.getItem("dsh.modelPickerPlus.diag");
	assert(diagRaw !== null, "g2) dsh.modelPickerPlus.diag 已写入（effect 真执行了）");
	if (diagRaw !== null) {
		console.log("diag = " + diagRaw);
		const p = JSON.parse(diagRaw);
		assert(
			(p.priority === null || typeof p.priority === "number") && typeof p.weRender === "boolean",
			"g3) diag.priority 为数字或 null、weRender 为布尔",
			"priority=" + String(p.priority) + " weRender=" + String(p.weRender),
		);
	}

	let renderThrew2 = null;
	try {
		exportsG.ModelSelectPlus(props);
	} catch (error) {
		renderThrew2 = error;
	}
	assert(renderThrew2 === null, "g4) 再次渲染未抛异常（hook 顺序稳定）", renderThrew2 === null ? "" : String(renderThrew2 && renderThrew2.message));
}


console.log("\n=== h) 启动竞态兜底：directoryFor 抛错后惰性自愈 ===");
{
	// 独立时钟与独立模块实例，避免先前场景挂起的看门狗干扰本场景。
	const clockH = createClock();
	const winH = createFakeWindow(storage, clockH, entriesRef);
	const loaderH = new Function(
		"window",
		"console",
		"navigator",
		"localStorage",
		"setTimeout",
		"clearTimeout",
		"setInterval",
		"clearInterval",
		"requestAnimationFrame",
		"cancelAnimationFrame",
		code,
	);
	loaderH(
		winH,
		consoleStub,
		winH.navigator,
		storage,
		clockH.setTimeout,
		clockH.clearTimeout,
		clockH.setInterval,
		clockH.clearInterval,
		winH.requestAnimationFrame,
		winH.cancelAnimationFrame,
	);
	const reactH = createReact(false);
	const requireH = (id) => {
		if (id === "react") return reactH;
		if (id === "react/jsx-runtime") return jsxStub;
		if (id === "react-dom") return reactDomStub;
		throw new Error("未预期的 require: " + id);
	};
	const exportsH = winH.__factory__(requireH);

	let directoryCalls = 0;
	let realSelectCalls = [];
	let realLoadCalls = 0;
	let realSubscriptions = 0;
	const realSnapshot = {
		status: "ready",
		error: null,
		groups: [{ id: "p1", name: "P1", models: [{ id: "m1", name: "M1" }, { id: "m2", name: "M2" }] }],
		failures: [],
		current: { provider: "p1", model: "m1" },
		default: { provider: "p1", model: "m1" },
	};
	const realDirectory = {
		store: {
			subscribe: () => {
				realSubscriptions += 1;
				return () => {
					realSubscriptions -= 1;
				};
			},
			getSnapshot: () => realSnapshot,
		},
		load: () => {
			realLoadCalls += 1;
			return Promise.resolve(undefined);
		},
		select: (selection) => {
			realSelectCalls.push(selection);
			return Promise.resolve({ ok: true });
		},
	};

	const slotsH = createSlots(entriesRef);
	const builtH = createCtx(slotsH, []);
	builtH.scope.modelDirectories = {
		directoryFor: (sessionId) => {
			directoryCalls += 1;
			if (directoryCalls < 3) {
				throw new Error('ui-model-selection: session "' + sessionId + '" resolved no scope/binding');
			}
			return realDirectory;
		},
	};
	let applyThrewH = null;
	try {
		exportsH.apply(builtH.ctx);
		resolveInjects(builtH.scope);
	} catch (error) {
		applyThrewH = error;
	}
	assert(applyThrewH === null, "h0) apply 未抛异常", applyThrewH === null ? "" : String(applyThrewH && applyThrewH.stack));

	const ownEntries = entriesRef.list.filter((e) => e.component === exportsH.ModelSelectPlus);
	assert(ownEntries.length === 1, "h0.1) 本场景恰注册一个条目", "own=" + ownEntries.length);
	const props = ownEntries[0].options.inject("h1-session");

	assert(props.available === true, "h1) available 按真实 sessions 计算（非兜底 false）", String(props.available));
	const emptyShot = props.directory.getSnapshot();
	assert(
		emptyShot.groups.length === 0 && emptyShot.status === "loading",
		"h2) 解析前 getSnapshot 返回 EMPTY（groups=0）",
		"groups=" + emptyShot.groups.length + " status=" + String(emptyShot.status),
	);

	let notified = 0;
	const unsubscribe = props.directory.subscribe(() => {
		notified += 1;
	});
	assert(notified === 0, "h3) 订阅即时 pump 未误报（directoryFor 仍在抛）", "notified=" + notified);
	// bootstrap 自身会先尝试一次 directoryFor（抛错被吞），订阅时的 pump 再试一次。
	assert(directoryCalls === 2, "h3.1) bootstrap + 即时 pump 各尝试一次（均失败）", "calls=" + directoryCalls);

	// 第一轮 400ms 轮询：第三次调用命中真实 directory。
	clockH.tick(400);
	assert(directoryCalls === 3, "h4) 400ms 轮询触发第三次 directoryFor 并命中", "calls=" + directoryCalls);
	assert(realSubscriptions === 1, "h4.1) 已订阅真实 store", "subs=" + realSubscriptions);
	assert(notified === 1, "h4.2) 解析成功后通知了监听者", "notified=" + notified);
	const liveShot = props.directory.getSnapshot();
	assert(
		liveShot === realSnapshot && liveShot.groups.length === 1 && liveShot.current.provider === "p1",
		"h5.3) getSnapshot 已委托真实 store",
		"groups=" + liveShot.groups.length + " current=" + JSON.stringify(liveShot.current),
	);

	const selectResult = props.select({ provider: "p1", model: "m2", reasoningEffort: null });
	assert(
		realSelectCalls.length === 1 && realSelectCalls[0].model === "m2" && selectResult instanceof Promise,
		"h6) select 解析后委托真实 directory",
		"calls=" + realSelectCalls.length + " isPromise=" + String(selectResult instanceof Promise),
	);
	props.load();
	assert(realLoadCalls === 1, "h6.1) load 解析后委托真实 directory", "loads=" + realLoadCalls);

	clockH.tick(400);
	assert(directoryCalls === 3, "h7) 解析后不再重复轮询", "calls=" + directoryCalls);
	assert(clockH.size < 8, "h7.1) 重试定时器已清理（仅剩看门狗）", "pending=" + clockH.size);

	unsubscribe();
	assert(realSubscriptions === 0, "h8) 退订传播到真实 store", "subs=" + realSubscriptions);
}


/* ------------------------------------------- 树状 react stub（场景 i 专用） */

// 与 createReact 的差别：保留 children（便于遍历真实元素树）、hook 状态跨渲染持久、
// useState 的 setter 真正写回（让「点击 → 重渲染」这条链路可测）。
// 不复用 createReact，避免影响 g/h 两个已通过的场景。
function createTreeReact() {
	const stateSlots = [];
	const refSlots = [];
	let cursor = 0;
	const stub = {
		Fragment: Symbol.for("react.fragment"),
		createElement: (type, props, ...children) => ({ type: type, props: props === undefined || props === null ? {} : props, children: children }),
		useState: (init) => {
			const slot = cursor;
			cursor += 1;
			if (stateSlots.length <= slot) stateSlots[slot] = typeof init === "function" ? init() : init;
			return [
				stateSlots[slot],
				(value) => {
					stateSlots[slot] = typeof value === "function" ? value(stateSlots[slot]) : value;
				},
			];
		},
		useRef: (init) => {
			const slot = cursor;
			cursor += 1;
			if (refSlots.length <= slot) refSlots[slot] = { current: init === undefined ? null : init };
			return refSlots[slot];
		},
		useEffect: (fn) => {
			fn();
		},
		useLayoutEffect: () => {},
		useMemo: (factory) => factory(),
		useCallback: (fn) => fn,
		useSyncExternalStore: (_sub, get) => (typeof get === "function" ? get() : null),
		useReducer: (init) => [init, () => {}],
		useContext: () => null,
		useImperativeHandle: () => {},
		forwardRef: (render) => render,
		memo: (component) => component,
		createContext: () => ({ Provider: fakeComponent("Provider"), Consumer: fakeComponent("Consumer") }),
	};
	return {
		stub: stub,
		begin: () => {
			cursor = 0;
		},
	};
}

// 深度遍历元素树；visitor 返回 true 表示继续，返回 false 表示提前结束。
function walkTree(node, visitor) {
	if (node === null || node === undefined || node === false || node === true) return true;
	if (Array.isArray(node)) {
		for (const child of node) {
			if (walkTree(child, visitor) === false) return false;
		}
		return true;
	}
	if (typeof node !== "object") return true;
	if (visitor(node) === false) return false;
	if (Array.isArray(node.children)) {
		for (const child of node.children) {
			if (walkTree(child, visitor) === false) return false;
		}
	}
	return true;
}

function findElement(tree, predicate) {
	let found = null;
	walkTree(tree, (node) => {
		if (node !== null && node.type !== undefined && predicate(node)) {
			found = node;
			return false;
		}
		return true;
	});
	return found;
}

function classNameOf(node) {
	const value = node !== null && node.props !== null && node.props !== undefined ? node.props.className : null;
	return typeof value === "string" ? value : "";
}

console.log("\n=== i) 免费/限免分组可折叠 ===");
{
	storage.clear();
	const clockI = createClock();
	const entriesRefI = { list: [] };
	const winI = createFakeWindow(storage, clockI, entriesRefI);
	const loaderI = new Function(
		"window",
		"console",
		"navigator",
		"localStorage",
		"setTimeout",
		"clearTimeout",
		"setInterval",
		"clearInterval",
		"requestAnimationFrame",
		"cancelAnimationFrame",
		"document",
		code,
	);
	loaderI(
		winI,
		consoleStub,
		winI.navigator,
		storage,
		clockI.setTimeout,
		clockI.clearTimeout,
		clockI.setInterval,
		clockI.clearInterval,
		winI.requestAnimationFrame,
		winI.cancelAnimationFrame,
	winI.document,
	);
	const reactI = createTreeReact();
	const requireI = (id) => {
		if (id === "react") return reactI.stub;
		if (id === "react/jsx-runtime") return jsxStub;
		if (id === "react-dom") return reactDomStub;
		throw new Error("未预期的 require: " + id);
	};
	const exportsI = winI.__factory__(requireI);

	const slotsI = createSlots(entriesRefI);
	const builtI = createCtx(slotsI, []);
	let applyThrewI = null;
	try {
		exportsI.apply(builtI.ctx);
		resolveInjects(builtI.scope);
	} catch (error) {
		applyThrewI = error;
	}
	assert(applyThrewI === null, "i0) apply 未抛异常", applyThrewI === null ? "" : String(applyThrewI && applyThrewI.stack));

	// 一个免费模型（名字命中 freeNamePatterns）+ 一个普通模型；当前模型是普通模型，
	// 这样免费分组不会被「当前模型自动展开」逻辑打开。
	const snapshotI = {
		status: "ready",
		error: null,
		groups: [
			{
				id: "p1",
				name: "P1",
				models: [
					{ id: "m1", name: "Free-M1" },
					{ id: "m2", name: "Paid-M2" },
				],
			},
		],
		failures: [],
		current: { provider: "p1", model: "m2" },
		default: { provider: "p1", model: "m2" },
	};
	const propsI = {
		locked: false,
		available: true,
		directory: { subscribe: () => () => {}, getSnapshot: () => snapshotI },
		select: () => Promise.resolve({ ok: true }),
		t: (k) => String(k),
		renderSlot: undefined,
	};
	const render = () => {
		reactI.begin();
		return exportsI.ModelSelectPlus(propsI);
	};

	let tree1 = null;
	let threw1 = null;
	try {
		tree1 = render();
	} catch (error) {
		threw1 = error;
	}
	assert(threw1 === null, "i1) 首次渲染未抛异常", threw1 === null ? "" : String(threw1 && threw1.message));

	const trigger = findElement(tree1, (node) => classNameOf(node).indexOf("dmpp-trigger") !== -1);
	assert(trigger !== null, "i2) 触发器按钮已渲染");
	let opened = false;
	if (trigger !== null && trigger.props !== null && typeof trigger.props.onClick === "function") {
		trigger.props.onClick();
		opened = true;
	}
	assert(opened, "i2.1) 已调用触发器 onClick（打开菜单）");

	let tree2 = null;
	let threw2 = null;
	try {
		tree2 = render();
	} catch (error) {
		threw2 = error;
	}
	assert(threw2 === null, "i3) 打开菜单后渲染未抛异常", threw2 === null ? "" : String(threw2 && threw2.message));

	const headerOpen = findElement(tree2, (node) => classNameOf(node).indexOf("dmpp-free-header") !== -1);
	assert(headerOpen !== null, "i4) 免费分组标题已渲染");
	assert(
		headerOpen !== null && headerOpen.type === "button",
		"i4.1) 免费分组标题是 button（可点击折叠）",
		headerOpen === null ? "no-header" : String(headerOpen.type),
	);
	assert(
		headerOpen !== null && headerOpen.props["aria-expanded"] === "true",
		"i4.2) 默认展开（aria-expanded=true）",
		headerOpen === null ? "no-header" : String(headerOpen.props["aria-expanded"]),
	);
	const freeRowOpen = findElement(
		tree2,
		(node) => classNameOf(node).indexOf("dmpp-option") !== -1 && node.props.title === "Free-M1",
	);
	assert(freeRowOpen !== null, "i5) 展开时免费模型行可见");

	let toggled = false;
	if (headerOpen !== null && typeof headerOpen.props.onClick === "function") {
		headerOpen.props.onClick();
		toggled = true;
	}
	assert(toggled, "i6) 已调用免费分组标题 onClick（折叠）");

	let tree3 = null;
	let threw3 = null;
	try {
		tree3 = render();
	} catch (error) {
		threw3 = error;
	}
	assert(threw3 === null, "i7) 折叠后渲染未抛异常", threw3 === null ? "" : String(threw3 && threw3.message));
	const headerClosed = findElement(tree3, (node) => classNameOf(node).indexOf("dmpp-free-header") !== -1);
	assert(
		headerClosed !== null && headerClosed.props["aria-expanded"] === "false",
		"i8) 折叠后 aria-expanded=false",
		headerClosed === null ? "no-header" : String(headerClosed.props["aria-expanded"]),
	);
	// 免费组不做去重：免费模型仍留在各自提供商分组里，所以这里只断言
	// 免费分区（.dmpp-section-free）内部不再有模型行。
	const freeSection = findElement(tree3, (node) => classNameOf(node).indexOf("dmpp-section-free") !== -1);
	assert(freeSection !== null, "i9) 免费分区仍渲染（仅收起内容）");
	let freeSectionRows = 0;
	if (freeSection !== null) {
		walkTree(freeSection, (node) => {
			if (classNameOf(node).indexOf("dmpp-option") !== -1) freeSectionRows += 1;
			return true;
		});
	}
	assert(freeSectionRows === 0, "i9.2) 折叠后免费分区内不再有模型行", "rows=" + freeSectionRows);
	const paidRowClosed = findElement(
		tree3,
		(node) => classNameOf(node).indexOf("dmpp-option") !== -1 && node.props.title === "Paid-M2",
	);
	assert(paidRowClosed !== null, "i9.1) 折叠免费分组不影响其它分组（Paid-M2 仍在）");
	const storedCollapsed = storage.getItem("dsh.modelPickerPlus.collapsed");
	assert(
		typeof storedCollapsed === "string" && storedCollapsed.indexOf("__free__") !== -1,
		"i10) 折叠状态已写入 localStorage（含 __free__）",
		String(storedCollapsed),
	);

	let reopened = false;
	if (headerClosed !== null && typeof headerClosed.props.onClick === "function") {
		headerClosed.props.onClick();
		reopened = true;
	}
	assert(reopened, "i11) 再次点击免费分组标题（展开）");
	let tree4 = null;
	let threw4 = null;
	try {
		tree4 = render();
	} catch (error) {
		threw4 = error;
	}
	assert(threw4 === null, "i12) 再展开后渲染未抛异常", threw4 === null ? "" : String(threw4 && threw4.message));
	const headerReopen = findElement(tree4, (node) => classNameOf(node).indexOf("dmpp-free-header") !== -1);
	assert(
		headerReopen !== null && headerReopen.props["aria-expanded"] === "true",
		"i13) 再展开后 aria-expanded=true 且免费行恢复",
		headerReopen === null ? "no-header" : String(headerReopen.props["aria-expanded"]),
	);
	const freeRowReopen = findElement(
		tree4,
		(node) => classNameOf(node).indexOf("dmpp-option") !== -1 && node.props.title === "Free-M1",
	);
	assert(freeRowReopen !== null, "i14) 再展开后免费模型行重新可见");
}


console.log("\n=== j) 弹层摆放：挂 body + 视口夹取（顶部不再被窗口裁掉） ===");
{
	const clockJ = createClock();
	const winJ = createFakeWindow(createStorage(), clockJ, { list: [] });
	const loaderJ = new Function(
		"window",
		"console",
		"navigator",
		"localStorage",
		"setTimeout",
		"clearTimeout",
		"setInterval",
		"clearInterval",
		"requestAnimationFrame",
		"cancelAnimationFrame",
		"document",
		code,
	);
	loaderJ(
		winJ,
		consoleStub,
		winJ.navigator,
		winJ.localStorage,
		clockJ.setTimeout,
		clockJ.clearTimeout,
		clockJ.setInterval,
		clockJ.clearInterval,
		winJ.requestAnimationFrame,
		winJ.cancelAnimationFrame,
		winJ.document,
	);
	const exportsJ = winJ.__factory__((id) => (id === "react" ? reactStub : id === "react-dom" ? reactDomStub : jsxStub));
	const internals = exportsJ !== undefined && exportsJ.__internals !== undefined ? exportsJ.__internals : null;
	assert(internals !== null && typeof internals.computeMenuPos === "function", "j0) computeMenuPos 可用于断言");
	const place = internals.computeMenuPos;
	const anchor = { left: 100, right: 300, top: 600, bottom: 620 };

	// 弹层比触发器宽：以右边缘对齐触发器右侧，越界则夹回左边距。
	const wide = place(anchor, { width: 360, height: 200 }, { width: 1000, height: 700 }, 12);
	assert(wide.left === 12, "j1) 过宽时左边缘夹到边距内", JSON.stringify(wide));
	assert(wide.top === 392, "j1.1) 上方空间够时贴着触发器向上展开", String(wide.top));

	// 关键回归：弹层比上方空间高时，顶部必须被夹进窗口（旧实现会被裁掉）。
	const tall = place(anchor, { width: 200, height: 600 }, { width: 1000, height: 800 }, 12);
	assert(tall.top === 12, "j2) 高弹层顶部被夹进窗口边距", String(tall.top));
	assert(tall.left === 100, "j2.1) 宽度不比触发器宽时仍对齐触发器右侧", String(tall.left));

	// 弹层比整个视口还高：仍然从顶部边距开始，且高度由 CSS max-height 兜住。
	const huge = place(anchor, { width: 200, height: 900 }, { width: 1000, height: 400 }, 12);
	assert(huge.top === 12, "j3) 超过视口高度时顶部仍可见", String(huge.top));

	// 量不到自身尺寸时退回触发器左侧，且不产生 NaN。
	const unmeasured = place(anchor, { width: 0, height: 0 }, { width: 1000, height: 700 }, 12);
	assert(unmeasured.left === 100, "j4) 未量到宽度时用触发器左边缘", String(unmeasured.left));
	assert(Number.isFinite(unmeasured.top), "j4.1) 未量到高度时不产生 NaN", String(unmeasured.top));

	// 视口尺寸未知（0 / 非数字）：不夹取也不产生 NaN。
	const unknownView = place(anchor, { width: 200, height: 200 }, { width: 0, height: Number.NaN }, 12);
	assert(Number.isFinite(unknownView.left) && Number.isFinite(unknownView.top), "j5) 视口未知时不产生 NaN", JSON.stringify(unknownView));

	// 产物结构：弹层必须是 body 上的固定定位元素，而不是参与输入框布局的 absolute 框。
	assert(code.indexOf(".dmpp-popup{position:fixed") !== -1, "j6) 产物弹层使用 position:fixed");
	assert(code.indexOf("bottom:calc(100% + 8px)") === -1, "j6.1) 已没有旧的 absolute 向上展开规则");
	assert(code.indexOf("createPortal") !== -1, "j6.2) 产物通过 createPortal 挂到 body");
	assert(code.indexOf("position:sticky") === -1, "j6.3) 分组头不再吸顶（滚动时随内容滚走）");
}

console.log("\n=== f) 汇总 ===");
assert(FAILURES === 0, "f) 全部断言通过", "failures=" + FAILURES);
process.exit(FAILURES === 0 ? 0 : 1);
