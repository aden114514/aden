# dsh-model-picker-plus

接管 DSH Web 输入区的模型选择器（插槽 `conversation.input.model`），在原生按钮位置换成自己的菜单，额外提供四项能力：

1. **强项标签**：每个模型名后跟最多 3 个小号弱化标签（如 `推理` `长上下文`），触发器上最多显示 2 个。
2. **按提供商折叠**：每个 provider 一个可点击分组头（provider 名 + 模型数 + 箭头），折叠时不渲染模型行。
3. **免费 / 限免置顶**：弹层最上方固定一个「免费 · 限免」分组，跨 provider 汇总所有命中免费判定的模型；该分组与 provider 分组一样可点击折叠（折叠状态同样存 localStorage，当前模型本身命中免费判定时自动展开）。这些模型同时仍保留在自己的 provider 分组里（不去重）。
**弹层摆放**：弹层用 `createPortal` 挂到 `document.body`、`position:fixed`，打开时按触发器矩形量好自身尺寸再夹进视口（四周留 12px 边距），窗口矮时也不会被输入框容器或窗口上沿裁掉——与内置选择器的做法一致。

4. **provider 内按强度排序**：有 `rank` 的按 `rank` 降序，没有 `rank` 的未知模型排在后面并保持原始顺序，`rank` 相同保持原始顺序。

## 安装

这是一个标准的 DSH Web 客户端插件（host 半身空壳 + 浏览器半身 ModuleLoader 模块）。

- 浏览器半身：`client.js`（**构建产物，装机用这个**）
- host 半身：`index.js`（空壳，只为让 `cordis.patch.yml` 有一行可挂载的插件行）
- 挂载补丁：`cordis.patch.yml`

```
- insert:
    - id: model-picker-plus
      name: 'dsh-model-picker-plus'
      config: {}
```

## 构建

```bash
node scripts/build-client.mjs
```

脚本只用 node 内置模块：

1. 读 `data/models.json`；缺失 / 解析失败 / 顶层形状不对时打印警告并退回空数据集（**不会失败**，插件按降级模式运行）；
2. 读 `src/client.js`，把唯一的占位符 `__DSH_MPP_DATA__` 替换成 `JSON.stringify(data)`，写 `client.js`；
3. 打印产物字节数与内联条目数；幂等（连续构建字节一致）。

改了 `src/client.js` 或 `data/models.json` 之后必须重新构建，否则装机的 `client.js` 还是旧数据。

## 数据契约（`data/models.json`）

```json
{
  "version": 1,
  "providerOrder": ["deepseek-account", "deepseek-official", "..."],
  "freeProviders": ["modlens-our-free-model"],
  "freeModels": [{ "provider": "buddy", "model": "hy3", "kind": "free", "note": "x0.00" }],
  "freeNamePatterns": ["x0\\\\.00", "免费", "free"],
  "models": {
    "deepseek-account/deepseek-v4-pro": { "rank": 96, "tags": ["推理", "长上下文"], "note": "可省略", "free": false }
  }
}
```

- `providerOrder`：provider 分组的显示顺序；不在列表里的 provider 排在最后（保持目录原始顺序）。
- `freeModels[].kind`：`"free"` 显示「免费」徽标，`"limited"` 显示「限免」；`provider` 允许写 `"*"` 表示按裸模型 id 匹配任意 provider。
- `freeNamePatterns`：按 `new RegExp(p, "i")` 匹配模型显示名；单条正则非法只跳过该条。
- `models` 键是 `provider/model`；`free: true` 优先级最高。`rank` 必须是有限数字，否则当作"无 rank"。

**免费判定优先级（信息更具体者优先）**：

1. `freeModels` 命中且 `kind === "limited"`（先 exact，再 `provider: "*"` 通配）→ 显示「限免」，并把该条的 `note` 作为徽标 title；
2. `models[key].free === true` → 显示「免费」；
3. `freeModels` 的其余命中（`kind === "free"`）→ 显示「免费」；
4. `freeProviders` 命中 provider → 显示「免费」；
5. `freeNamePatterns` 命中显示名 → 显示「免费」。

「限免」比「免费」更具体，因此清单里的 limited 条目会盖过同一条目的 `free === true`；分组归属、置顶、去重与 provider 内排序不受这一判定影响。

## 降级行为

- 数据缺失 / 损坏：无标签、无免费判定、按目录原始顺序渲染，不崩。
- `available === false`（子会话）或 `locked`：触发器禁用、弹层只显示只读提示、所有行 disabled，不报错。
- snapshot 为 `loading` 或 `error`：弹层内显示可见文案，不崩。
- `select()` 无论 reject 还是 resolve `{ ok: false, error }`，错误都只以文本呈现在弹层里（不 throw），`error.code === "session/writer-held"` 有专门文案。
- localStorage 不可用（隐私模式）：折叠状态退回内存默认值，不崩。

## 折叠状态

存 `localStorage` 的 `dsh.modelPickerPlus.collapsed`，值是**已折叠**的分组 id 字符串数组（provider id，外加免费分组的哨兵 id `__free__`）。首次使用（该键不存在）时只展开当前模型所属 provider、其余全部折叠（免费分组默认展开）；当前 provider 变化、或当前模型本身是免费模型时会自动展开对应分组。

## 交互

- 点触发器开关弹层；Escape 关闭；点外部关闭；关闭后焦点回到触发器。
- 上下键在可见模型行之间移动（`Home`/`End` 到首尾），Enter 选择，Space 选中分组头时折叠/展开。
- `aria-haspopup="menu"` / `role="menu"` / `role="menuitemradio"` / `aria-expanded` / `aria-checked` 齐全，`:focus-visible` 有可见焦点环。
- 模型条目总数 > 12 时，弹层顶部出现搜索框，按模型名 / provider / 标签模糊过滤，即时过滤且保持分组结构。
- 当前模型有 `reasoning.efforts` 时，在该行下方给一行 effort 选项；点 effort 以 `{ provider, model, reasoningEffort }` 调 `select`，点模型行本身则沿用当前 / 默认 effort（不会静默丢掉 effort）。

## 样式

自带一段 `<style>`（`data-plugin-css="dsh-model-picker-plus/picker.css"` 去重注入），所有 class 以 `dmpp-` 前缀。颜色优先用 DSH 主题变量（`--dsw-alias-label-primary`、`--dsw-alias-bg-layer-1`、`--dsw-elevation-panel`、`--dsw-focus-ring-color` 等，都带 fallback），变量缺失时退回中性 rgba。

## 已知契约风险

1. **`renderSlot` 很可能是 `undefined`**。渲染器只在该插槽注册项自带 `children` 时才下发 `renderSlot`，而 `conversation.input.model.label` 已被内置选择器声明过，重复声明会抛错——所以本插件不能带 `children`。代码里用 `typeof renderSlot === "function"` + try/catch 兜住，回退到 `model.name`。代价：其它 label 插件大概**不会**给本菜单里的模型名加装饰。
2. 内置选择器调 `renderSlot` 时第三个参数是 `placement: "option"`（任务说明里写的 `variant`），本插件两键都传以兼容。
3. 内置 `/model` 路径里 `select()` 是 **resolve** `{ ok, error }` 而不是 reject，两种都处理了。
4. 折叠状态存的是"已折叠 id 数组"，后加的 provider 默认展开（不是默认折叠）。
5. 免费分组用哨兵 id `__free__` 复用同一个折叠数组；若未来某个 provider 的 id 恰好等于 `__free__`（不会发生），会与免费分组共享折叠状态。
5. 覆盖仅靠 `priority: -1`（单例插槽"最低优先级渲染"）。若将来有别的插件也用负优先级抢占，同优先级会抛错、更低优先级会覆盖本插件。
