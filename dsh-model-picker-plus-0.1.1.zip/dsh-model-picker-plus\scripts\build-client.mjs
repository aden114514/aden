/**
 * dsh-model-picker-plus - 构建脚本（只用 node 内置模块）。
 *
 * 1. 读 data/models.json；缺失或解析失败时用空数据集兜底并打印警告（不失败）；
 * 2. 读 src/client.js，把占位符替换为 JSON.stringify(数据)，写 client.js；
 * 3. 打印产物字节数与内联条目数；
 * 4. 幂等：同样的输入永远产出同样的字节。
 */
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(HERE, "..");
const TEMPLATE = join(ROOT, "src", "client.js");
const OUTPUT = join(ROOT, "client.js");
const DATA_FILE = join(ROOT, "data", "models.json");
const PLACEHOLDER = "__DSH_MPP_DATA__";

const EMPTY_DATA = {
	version: 1,
	providerOrder: [],
	freeProviders: [],
	freeModels: [],
	freeNamePatterns: [],
	models: {},
};

function loadData() {
	if (!existsSync(DATA_FILE)) {
		console.warn("[build-client] 警告：data/models.json 不存在，使用空数据集兜底（插件会降级运行）");
		return { data: EMPTY_DATA, source: "fallback:missing" };
	}
	let parsed;
	try {
		parsed = JSON.parse(readFileSync(DATA_FILE, "utf8"));
	} catch (error) {
		const message = error !== null && typeof error === "object" && typeof error.message === "string" ? error.message : String(error);
		console.warn("[build-client] 警告：data/models.json 解析失败（" + message + "），使用空数据集兜底");
		return { data: EMPTY_DATA, source: "fallback:invalid" };
	}
	if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed)) {
		console.warn("[build-client] 警告：data/models.json 顶层不是对象，使用空数据集兜底");
		return { data: EMPTY_DATA, source: "fallback:shape" };
	}
	return { data: parsed, source: "data/models.json" };
}

const template = readFileSync(TEMPLATE, "utf8");
const occurrences = template.split(PLACEHOLDER).length - 1;
if (occurrences !== 1) {
	console.error(
		"[build-client] 失败：src/client.js 里占位符 " + PLACEHOLDER + " 必须恰好出现 1 次，实际出现 " + occurrences + " 次",
	);
	process.exit(1);
}

const loaded = loadData();
const inlined = JSON.stringify(loaded.data);
const output = template.split(PLACEHOLDER).join(inlined);
writeFileSync(OUTPUT, output, "utf8");

const entryCount =
	loaded.data.models !== null && typeof loaded.data.models === "object" && !Array.isArray(loaded.data.models)
		? Object.keys(loaded.data.models).length
		: 0;

console.log("[build-client] 数据来源：" + loaded.source);
console.log("[build-client] 产物：" + OUTPUT);
console.log("[build-client] 产物字节数：" + Buffer.byteLength(output, "utf8"));
console.log("[build-client] 内联条目数：" + entryCount);
