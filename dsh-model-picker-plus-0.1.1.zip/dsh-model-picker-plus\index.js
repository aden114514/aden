/**
 * dsh-model-picker-plus — host half.
 *
 * 本插件的全部可见行为都在浏览器半身（./client.js）里，Host 侧只需要一个能被
 * loader 挂载的 cordis 插件条目。这里刻意什么都不做：不注册服务、不挂 HTTP 路由、
 * 不写文件、不碰 data/ 目录。
 */
export const name = "dsh-model-picker-plus";
export const inject = [];
export function apply() {}
