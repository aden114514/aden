# models.json 数据说明

模型选择器插件唯一的数据源：`data/models.json`。键名固定，勿改名。

## 字段
- `version`：schema 版本，当前为 1。
- `providerOrder`：provider 由强到弱排列，UI 用它决定分组顺序；第一个是最强的渠道。
- `freeProviders`：整条渠道免费/限免的 provider（该渠道下所有模型都视为免费）。
- `freeModels`：清单式免费/限免模型，`kind` 取 `free`（永久免费）或 `limited`（限时/订阅限免），`note` 是展示用的价格标记。
- `freeNamePatterns`：JS 正则字符串数组，插件拿模型显示名去匹配，命中即判定免费（如 `x0\\.00`、`免费`、`free`）。
- `models`：键为 `"<provider>/<model>"`，必须与 `list_models` 输出逐字一致（大小写敏感）。
  - `rank`：0-100 整数，越大越强，同一 provider 内必须互不相同（不允许并列）。
  - `tags`：1-3 个中文强项标签，只能取自固定词表：推理 / 代码 / 长上下文 / 视觉 / 中文 / 通用 / 速度 / 工具调用 / 轻量 / 数学 / 多模态对齐。
  - `note`：可选，一句短语（当前只用于免费条目的价格标记和自动路由说明）。
  - `free`：布尔，必须与 `freeProviders` / `freeModels` 的推导结果一致。

## rank 口径
- 先按模型家族规格定分：Kimi-K3、DeepSeek-V4-Pro-0813 = 93；DeepSeek-V4-Pro / Qwen3.8-Max = 92；GLM-5.3 = 91；Qwen3.7-Max = 90；GLM-5.2、V4.1-Flash、MiniMax-M3 = 88；Pro/Plus = 84-87；Flash/Turbo/Preview = 76-84；小尺寸/分类器/安全模型 = 30-60。
- 同一渠道内多个模型同分时，按模型名字典序取前者的原始分，后续逐次减 1，保证 provider 内 rank 唯一且不破坏强弱顺序。
- 因此跨 provider 可以并列（同一个模型在不同渠道同分），provider 内绝不并列。

## 怎么改
- 新增模型：在 `models` 里加 `"<provider>/<model>": { "rank": 80, "tags": ["通用"], "free": false }`；确认该 provider 已在 `providerOrder` 中，且同 provider 内 rank 未占用。
- 改免费判定：整个渠道免费就加进 `freeProviders`；单个模型免费就加进 `freeModels`（或直接把该条目的 `free` 改 true）；显示名规则类免费就改 `freeNamePatterns`。
- 下架模型：删除对应条目；如果整个 provider 都没了，同时从 `providerOrder` 移除。
- 改完跑校验：`node <临时目录>/validate-models.js <临时目录>/mp_catalog.json data/models.json`，全绿再提交（临时脚本不入库）。
